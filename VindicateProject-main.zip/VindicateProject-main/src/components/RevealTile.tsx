import React from 'react';
import { HelpCircle } from 'lucide-react';

interface RevealTileProps {
  diagnosis: string;
  clickCount: number;
  onReveal: () => void;
  onHide: () => void;
  isRevealed: boolean;
  isDangerous?: boolean;
}

const RevealTile: React.FC<RevealTileProps> = ({ 
  diagnosis, 
  clickCount, 
  onReveal,
  onHide,
  isRevealed = false, // DEFAULT: false = question mark visible
  isDangerous = false
}) => {
  const handleClick = () => {
    if (isRevealed) {
      // Currently showing diagnosis, flip back to question mark
      onHide();
    } else {
      // Currently showing question mark, flip to reveal diagnosis
      onReveal();
    }
  };

  // FIXED: Separate glow classes that don't interfere with 3D transforms
  const getDangerousGlowClass = () => {
    if (isDangerous) {
      return 'border-2 border-red-900 shadow-lg shadow-red-900/70';
    }
    return 'border border-light-gray dark:border-white hover:shadow-futuristic hover:scale-105';
  };

  return (
    <div className="perspective-1000 w-full">
      <div 
        className={`
          w-full h-14 sm:h-16 relative transition-transform duration-700 ease-in-out rounded-luxury
          ${isRevealed ? 'rotate-y-180' : ''} 
        `}
        style={{
          transformStyle: 'preserve-3d',
          WebkitTransformStyle: 'preserve-3d',
          MozTransformStyle: 'preserve-3d'
        }}
      >
        {/* Front Face - Question Mark (DEFAULT - VISIBLE when isRevealed=false) */}
        <div 
          className={`
            absolute inset-0 bg-soft-gray dark:bg-dark-surface-elevated rounded-luxury
            flex items-center justify-center cursor-pointer transition-all duration-300 shadow-luxury-soft dark:shadow-dark-soft
            min-h-[56px] sm:min-h-[60px] focus:outline-none focus:ring-2 focus:ring-burgundy-red focus:ring-opacity-50
            ${getDangerousGlowClass()}
          `}
          onClick={handleClick}
          tabIndex={0}
          role="button"
          onKeyDown={(e) => {
            if (e.key === 'Enter' || e.key === ' ') {
              e.preventDefault();
              handleClick();
            }
          }}
          style={{
            backfaceVisibility: 'hidden',
            WebkitBackfaceVisibility: 'hidden',
            MozBackfaceVisibility: 'hidden',
            msBackfaceVisibility: 'hidden'
          }}
        >
          <span className="text-base font-bold text-royal-blue dark:text-white">?</span>
        </div>

        {/* Back Face - Diagnosis Text (REVEALED when isRevealed=true) */}
        <div 
          className={`
            absolute inset-0 bg-soft-gray dark:bg-dark-surface-elevated rounded-luxury
            flex items-center justify-center cursor-pointer transition-all duration-300 shadow-luxury-soft dark:shadow-dark-soft
            ${getDangerousGlowClass()}
            focus:outline-none focus:ring-2 focus:ring-burgundy-red focus:ring-opacity-50
            py-3 sm:py-4 px-4 sm:px-5 min-h-[56px] sm:min-h-[60px]
          `}
          onClick={handleClick}
          tabIndex={0}
          role="button"
          onKeyDown={(e) => {
            if (e.key === 'Enter' || e.key === ' ') {
              e.preventDefault();
              handleClick();
            }
          }}
          style={{ 
            transform: 'rotateY(180deg)',
            WebkitTransform: 'rotateY(180deg)',
            MozTransform: 'rotateY(180deg)',
            backfaceVisibility: 'hidden',
            WebkitBackfaceVisibility: 'hidden',
            MozBackfaceVisibility: 'hidden',
            msBackfaceVisibility: 'hidden'
          }}
        >
          {/* Centered diagnosis text - Only visible when fully flipped */}
          <div className="flex items-center justify-center w-full">
            <h3 className="font-cambria text-xs font-normal tracking-elegant leading-tight text-royal-blue dark:text-white text-center max-w-full">
              {diagnosis}
            </h3>
          </div>
        </div>
      </div>
    </div>
  );
};

export default RevealTile;