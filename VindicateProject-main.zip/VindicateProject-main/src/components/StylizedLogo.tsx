import React from 'react';

interface StylizedLogoProps {
  size?: 'sm' | 'md' | 'lg' | 'xl';
  className?: string;
}

const StylizedLogo: React.FC<StylizedLogoProps> = ({ size = 'md', className = '' }) => {
  const getSizeClasses = () => {
    switch (size) {
      case 'sm': return 'w-8 h-8';
      case 'md': return 'w-12 h-12';
      case 'lg': return 'w-16 h-16';
      case 'xl': return 'w-20 h-20';
      default: return 'w-12 h-12';
    }
  };

  return (
    <div className={`${getSizeClasses()} ${className} relative flex items-center justify-center`}>
      {/* Outer Ring with Gradient */}
      <div className="absolute inset-0 rounded-full bg-gradient-to-br from-burgundy-red via-dusty-rose to-gold-accent opacity-90 animate-pulse"></div>
      
      {/* Inner Circle Background */}
      <div className="absolute inset-1 rounded-full bg-pure-white dark:bg-dark-surface shadow-inner"></div>
      
      {/* Magnifying Glass Handle */}
      <div className="absolute -bottom-1 -right-1 w-3 h-6 bg-gradient-to-b from-slate-blue to-burgundy-red rounded-full transform rotate-45 shadow-lg"></div>
      
      {/* Magnifying Glass Lens */}
      <div className="relative w-8 h-8 rounded-full border-2 border-burgundy-red bg-gradient-to-br from-transparent via-burgundy-red/10 to-burgundy-red/20 flex items-center justify-center">
        {/* Inner Lens Reflection */}
        <div className="w-2 h-2 rounded-full bg-gradient-to-br from-pure-white to-transparent opacity-60 absolute top-1 left-1"></div>
        
        {/* Center Crosshair */}
        <div className="absolute inset-0 flex items-center justify-center">
          <div className="w-4 h-0.5 bg-burgundy-red opacity-40"></div>
          <div className="absolute w-0.5 h-4 bg-burgundy-red opacity-40"></div>
        </div>
      </div>
      
      {/* Sparkle Effects */}
      <div className="absolute -top-1 -left-1 w-1 h-1 bg-gold-accent rounded-full animate-ping"></div>
      <div className="absolute -bottom-1 -left-2 w-0.5 h-0.5 bg-dusty-rose rounded-full animate-pulse"></div>
      <div className="absolute -top-2 -right-1 w-0.5 h-0.5 bg-slate-blue rounded-full animate-ping" style={{ animationDelay: '1s' }}></div>
    </div>
  );
};

export default StylizedLogo;