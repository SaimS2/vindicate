import React from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { Home, ArrowLeft } from 'lucide-react';

const NavigationBar: React.FC = () => {
  const navigate = useNavigate();
  const { category } = useParams<{ category: string }>();

  const handleBack = () => {
    window.history.back();
  };

  const handleHome = () => {
    navigate('/age-categories'); // Changed to go to patient demographics
  };

  const handleVindicateLetter = (letter: string) => {
    const letterToCategory: Record<string, string> = {
      'V': 'vascular',
      'I': 'infectious', 
      'N': 'neoplastic',
      'D': 'degenerative',
      'I2': 'idiopathic', // Second I
      'C': 'congenital',
      'A': 'autoimmune',
      'T': 'traumatic',
      'E': 'endocrine'
    };
    
    const targetCategory = letterToCategory[letter];
    if (targetCategory) {
      navigate(`/reveal-differentials/${targetCategory}`);
    }
  };

  // Only show VINDICATE navigation on differential pages
  const showVindicateNav = window.location.pathname.includes('/reveal-differentials/');

  return (
    <nav className="fixed top-0 left-0 right-0 z-40 bg-pure-white dark:bg-dark-surface border-b border-divider-gray dark:border-dark-border backdrop-blur-luxury shadow-soft dark:shadow-dark-soft transition-colors duration-300">
      <div className="container mx-auto px-4 sm:px-6 py-3 sm:py-4">
        <div className="flex items-center justify-between">
          {/* Left: Navigation Buttons */}
          <div className="flex items-center space-x-2 sm:space-x-3">
            <button
              onClick={handleBack}
              className="
                flex items-center justify-center p-2 sm:p-3 rounded-luxury 
                bg-soft-gray dark:bg-dark-surface-elevated border border-royal-blue dark:border-white
                hover:bg-royal-blue hover:bg-opacity-10 hover:border-royal-blue hover:border-opacity-40 
                dark:hover:bg-royal-blue dark:hover:bg-opacity-20 dark:hover:border-white
                transition-all duration-300 min-h-[40px] min-w-[40px] sm:min-h-[44px] sm:min-w-[44px]
                focus:outline-none focus:ring-2 focus:ring-royal-blue focus:ring-opacity-50
                active:scale-95
              "
            >
              <ArrowLeft className="w-4 h-4 text-royal-blue dark:text-white" />
            </button>

            <button
              onClick={handleHome}
              className="
                flex items-center justify-center p-2 sm:p-3 rounded-luxury 
                bg-soft-gray dark:bg-dark-surface-elevated border border-royal-blue dark:border-white
                hover:bg-royal-blue hover:bg-opacity-10 hover:border-royal-blue hover:border-opacity-40 
                dark:hover:bg-royal-blue dark:hover:bg-opacity-20 dark:hover:border-white
                transition-all duration-300 min-h-[40px] min-w-[40px] sm:min-h-[44px] sm:min-w-[44px]
                focus:outline-none focus:ring-2 focus:ring-royal-blue focus:ring-opacity-50
                active:scale-95
              "
            >
              <Home className="w-4 h-4 text-royal-blue dark:text-white" />
            </button>
          </div>

          {/* Center: VINDICATE Navigation - FIXED: Same size as home button */}
          {showVindicateNav && (
            <div className="flex items-center space-x-2 sm:space-x-3">
              {[
                { letter: 'V', category: 'vascular' },
                { letter: 'I', category: 'infectious' },
                { letter: 'N', category: 'neoplastic' },
                { letter: 'D', category: 'degenerative' },
                { letter: 'I', category: 'idiopathic' },
                { letter: 'C', category: 'congenital' },
                { letter: 'A', category: 'autoimmune' },
                { letter: 'T', category: 'traumatic' },
                { letter: 'E', category: 'endocrine' }
              ].map((item, index) => {
                const isActive = category === item.category;
                return (
                  <span
                    key={`${item.letter}-${index}`}
                    onClick={() => handleVindicateLetter(item.letter === 'I' && index === 4 ? 'I2' : item.letter)}
                    className={`
                      cursor-pointer transition-all duration-300 text-sm sm:text-base font-cambria font-bold select-none
                      active:scale-95 hover:scale-110
                      ${isActive 
                        ? 'text-royal-blue dark:text-white underline decoration-2 underline-offset-2' 
                        : 'text-royal-blue dark:text-white hover:text-royal-blue dark:hover:text-white hover:opacity-80'
                      }
                    `}
                  >
                    {item.letter}
                  </span>
                );
              })}
            </div>
          )}

          {/* Right: Spacer to balance layout */}
          <div className="w-[88px] sm:w-[100px]"></div>
        </div>
      </div>
    </nav>
  );
};

export default NavigationBar;