import React from 'react';
import { Moon, Sun } from 'lucide-react';
import { useTheme } from '../contexts/ThemeContext';

const DarkModeToggle: React.FC = () => {
  const { isDarkMode, toggleDarkMode } = useTheme();

  return (
    <div className="fixed top-4 right-4 z-50">
      <button
        onClick={toggleDarkMode}
        className={`
          relative w-16 h-8 rounded-full transition-all duration-300 ease-in-out
          focus:outline-none focus:ring-2 focus:ring-royal-blue focus:ring-opacity-50
          ${isDarkMode 
            ? 'bg-royal-blue shadow-lg' 
            : 'bg-light-gray shadow-md'
          }
        `}
        aria-label={isDarkMode ? 'Switch to light mode' : 'Switch to dark mode'}
      >
        {/* Sliding Circle */}
        <div
          className={`
            absolute top-1 w-6 h-6 rounded-full transition-all duration-300 ease-in-out
            flex items-center justify-center shadow-md
            ${isDarkMode 
              ? 'left-9 bg-dark-surface' 
              : 'left-1 bg-pure-white'
            }
          `}
        >
          {isDarkMode ? (
            <Moon className="w-3 h-3 text-white" />
          ) : (
            <Sun className="w-3 h-3 text-royal-blue" />
          )}
        </div>
        
        {/* Background Icons */}
        <div className="absolute inset-0 flex items-center justify-between px-2">
          <Sun className={`w-3 h-3 transition-opacity duration-300 ${isDarkMode ? 'opacity-40 text-white' : 'opacity-0 text-slate-gray'}`} />
          <Moon className={`w-3 h-3 transition-opacity duration-300 ${isDarkMode ? 'opacity-0 text-white' : 'opacity-40 text-slate-gray'}`} />
        </div>
      </button>
    </div>
  );
};

export default DarkModeToggle;