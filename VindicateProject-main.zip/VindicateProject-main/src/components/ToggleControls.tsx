import React from 'react';
import { Clock, User, Calendar } from 'lucide-react';

interface ToggleControlsProps {
  chronicity: number; // in hours (0.017 = 1 minute, 8760 = 1 year)
  onChronicityChange: (hours: number) => void;
  biologicalSex: 'male' | 'female';
  onBiologicalSexChange: (sex: 'male' | 'female') => void;
  age: number;
  onAgeChange: (age: number) => void;
  ageRange: { min: number; max: number };
  category?: string;
}

const ToggleControls: React.FC<ToggleControlsProps> = ({
  chronicity,
  onChronicityChange,
  biologicalSex,
  onBiologicalSexChange,
  age,
  onAgeChange,
  ageRange,
  category
}) => {
  // Convert hours to display format
  const getChronicityDisplay = (hours: number) => {
    if (hours < 1) {
      const minutes = Math.round(hours * 60);
      return `${minutes} min${minutes !== 1 ? 's' : ''}`;
    } else if (hours < 24) {
      return `${Math.round(hours)} hr${Math.round(hours) !== 1 ? 's' : ''}`;
    } else if (hours < 168) { // Less than a week
      const days = Math.round(hours / 24);
      return `${days} day${days !== 1 ? 's' : ''}`;
    } else if (hours < 730) { // Less than a month
      const weeks = Math.round(hours / 168);
      return `${weeks} week${weeks !== 1 ? 's' : ''}`;
    } else if (hours < 8760) { // Less than a year
      const months = Math.round(hours / 730);
      return `${months} month${months !== 1 ? 's' : ''}`;
    } else {
      const years = Math.round(hours / 8760);
      return `${years} year${years !== 1 ? 's' : ''}`;
    }
  };

  // Convert slider value (0-100) to hours (1 minute to 1 year)
  const sliderToHours = (sliderValue: number) => {
    // Logarithmic scale: 0 = 1 minute, 100 = 1 year
    const minHours = 0.017; // 1 minute
    const maxHours = 8760; // 1 year
    return minHours * Math.pow(maxHours / minHours, sliderValue / 100);
  };

  // Convert hours to slider value (0-100)
  const hoursToSlider = (hours: number) => {
    const minHours = 0.017;
    const maxHours = 8760;
    return (Math.log(hours / minHours) / Math.log(maxHours / minHours)) * 100;
  };

  const handleChronicitySliderChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const sliderValue = parseInt(e.target.value);
    const hours = sliderToHours(sliderValue);
    onChronicityChange(hours);
  };

  return (
    <div className="space-y-3 mb-6">
      {/* Chronicity Slider */}
      <div className="bg-soft-gray dark:bg-dark-surface-elevated rounded-luxury px-3 py-2.5 border border-light-gray dark:border-white">
        <div className="flex items-center space-x-2 mb-2">
          <Clock className="w-3.5 h-3.5 text-royal-blue dark:text-white" />
          <span className="text-xs font-cambria text-royal-blue dark:text-white">
            Chronicity: {getChronicityDisplay(chronicity)}
          </span>
        </div>
        <input
          type="range"
          min="0"
          max="100"
          value={hoursToSlider(chronicity)}
          onChange={handleChronicitySliderChange}
          className="w-full h-1.5 bg-light-gray dark:bg-dark-border rounded-luxury appearance-none cursor-pointer slider"
          style={{
            background: `linear-gradient(to right, #1E3A8A 0%, #1E3A8A ${hoursToSlider(chronicity)}%, #DDDDDD ${hoursToSlider(chronicity)}%, #DDDDDD 100%)`
          }}
        />
        <div className="flex justify-between text-[10px] text-royal-blue dark:text-white opacity-60 mt-0.5">
          <span>1 min</span>
          <span>1 year</span>
        </div>
      </div>

      {/* Biological Sex Toggle */}
      <div className="bg-soft-gray dark:bg-dark-surface-elevated rounded-luxury px-3 py-2.5 border border-light-gray dark:border-white">
        <div className="flex items-center space-x-2 mb-2">
          <User className="w-3.5 h-3.5 text-royal-blue dark:text-white" />
          <span className="text-xs font-cambria text-royal-blue dark:text-white">
            Biological Sex
          </span>
        </div>
        <div className="flex space-x-1.5">
          <button
            onClick={() => onBiologicalSexChange('male')}
            className={`
              flex-1 py-1.5 px-3 rounded-luxury text-xs font-cambria transition-all duration-300
              ${biologicalSex === 'male'
                ? 'bg-royal-blue text-white shadow-sm'
                : 'bg-light-gray dark:bg-dark-border text-royal-blue dark:text-white hover:bg-royal-blue hover:bg-opacity-20'
              }
            `}
          >
            Male
          </button>
          <button
            onClick={() => onBiologicalSexChange('female')}
            className={`
              flex-1 py-1.5 px-3 rounded-luxury text-xs font-cambria transition-all duration-300
              ${biologicalSex === 'female'
                ? 'bg-royal-blue text-white shadow-sm'
                : 'bg-light-gray dark:bg-dark-border text-royal-blue dark:text-white hover:bg-royal-blue hover:bg-opacity-20'
              }
            `}
          >
            Female
          </button>
        </div>
      </div>

      {/* Age Slider */}
      <div className="bg-soft-gray dark:bg-dark-surface-elevated rounded-luxury px-3 py-2.5 border border-light-gray dark:border-white">
        <div className="flex items-center space-x-2 mb-2">
          <Calendar className="w-3.5 h-3.5 text-royal-blue dark:text-white" />
          <span className="text-xs font-cambria text-royal-blue dark:text-white">
            Age: {age} years
          </span>
        </div>
        <input
          type="range"
          min={ageRange.min}
          max={ageRange.max}
          value={age}
          onChange={(e) => onAgeChange(parseInt(e.target.value))}
          className="w-full h-1.5 bg-light-gray dark:bg-dark-border rounded-luxury appearance-none cursor-pointer slider"
          style={{
            background: `linear-gradient(to right, #1E3A8A 0%, #1E3A8A ${((age - ageRange.min) / (ageRange.max - ageRange.min)) * 100}%, #DDDDDD ${((age - ageRange.min) / (ageRange.max - ageRange.min)) * 100}%, #DDDDDD 100%)`
          }}
        />
        <div className="flex justify-between text-[10px] text-royal-blue dark:text-white opacity-60 mt-0.5">
          <span>{ageRange.min}</span>
          <span>{ageRange.max}</span>
        </div>
      </div>
    </div>
  );
};

export default ToggleControls;