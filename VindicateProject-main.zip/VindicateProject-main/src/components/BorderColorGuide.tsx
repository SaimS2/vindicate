import React, { useState } from 'react';
import { Info, RotateCcw } from 'lucide-react';

interface BorderColorGuideProps {
  onReset: () => void;
}

const BorderColorGuide: React.FC<BorderColorGuideProps> = ({ onReset }) => {
  const [isRevealed, setIsRevealed] = useState(false);

  const handleReveal = () => {
    setIsRevealed(!isRevealed);
  };

  return (
    <div className="perspective-1000 w-full mb-4 sm:mb-6">
      <div 
        className={`
          w-full h-40 sm:h-44 relative transform-style-preserve-3d transition-transform duration-700 rounded-luxury
          ${isRevealed ? 'rotate-y-180' : ''}
        `}
      >
        {/* Front Face - Navy Blue in Light Mode, White in Dark Mode */}
        <div 
          className={`
            absolute inset-0 backface-hidden bg-royal-blue dark:bg-pure-white rounded-luxury border border-royal-blue dark:border-charcoal-black
            flex items-center justify-center cursor-pointer transition-all duration-300 shadow-luxury-soft dark:shadow-dark-soft
            hover:shadow-futuristic hover:scale-105 min-h-[44px]
            focus:outline-none focus:ring-2 focus:ring-slate-blue focus:ring-opacity-50
            ${!isRevealed ? 'block' : 'hidden'}
          `}
          onClick={handleReveal}
          tabIndex={0}
          role="button"
          onKeyDown={(e) => {
            if (e.key === 'Enter' || e.key === ' ') {
              e.preventDefault();
              handleReveal();
            }
          }}
        >
          <div className="flex items-center justify-center space-x-4 sm:space-x-6 px-6 sm:px-8">
            <div className="w-8 h-8 sm:w-10 sm:h-10 rounded-full bg-pure-white bg-opacity-20 dark:bg-charcoal-black dark:bg-opacity-20 flex items-center justify-center shadow-elegant">
              <Info className="w-4 h-4 sm:w-5 sm:h-5 text-pure-white dark:text-charcoal-black" />
            </div>
            <span className="font-cambria text-sm sm:text-base text-center tracking-elegant text-pure-white dark:text-charcoal-black font-medium leading-relaxed">
              Border Color Guidelines
            </span>
          </div>
        </div>

        {/* Back Face - Navy Blue in Light Mode, White in Dark Mode */}
        <div 
          className={`
            absolute inset-0 backface-hidden rotate-y-180 bg-royal-blue dark:bg-pure-white rounded-luxury border border-royal-blue dark:border-charcoal-black p-4 sm:p-6
            flex items-center justify-between transition-all duration-300 shadow-luxury-soft dark:shadow-dark-soft
            ${isRevealed ? 'block' : 'hidden'}
            cursor-pointer focus:outline-none focus:ring-2 focus:ring-slate-blue focus:ring-opacity-50
          `}
          style={{ 
            transform: 'rotateY(180deg)' 
          }}
          onClick={handleReveal}
          tabIndex={0}
          role="button"
          onKeyDown={(e) => {
            if (e.key === 'Enter' || e.key === ' ') {
              e.preventDefault();
              handleReveal();
            }
          }}
        >
          <div className="flex-1 flex items-center justify-center pr-3 sm:pr-4">
            <div className="text-center space-y-2 max-w-full">
              <p className="font-cambria text-xs sm:text-sm font-medium text-pure-white dark:text-charcoal-black leading-tight mb-3">
                Borders indicate view frequency
              </p>
              
              {/* Compact Vertical Color Guide */}
              <div className="space-y-1.5">
                <div className="flex items-center justify-center space-x-2">
                  <span className="font-cambria text-xs text-pure-white dark:text-charcoal-black font-semibold min-w-[35px] text-left">Red:</span>
                  <span className="font-cambria text-xs text-pure-white dark:text-charcoal-black">1–10 views</span>
                </div>
                <div className="flex items-center justify-center space-x-2">
                  <span className="font-cambria text-xs text-pure-white dark:text-charcoal-black font-semibold min-w-[35px] text-left">Yellow:</span>
                  <span className="font-cambria text-xs text-pure-white dark:text-charcoal-black">11–20 views</span>
                </div>
                <div className="flex items-center justify-center space-x-2">
                  <span className="font-cambria text-xs text-pure-white dark:text-charcoal-black font-semibold min-w-[35px] text-left">Green:</span>
                  <span className="font-cambria text-xs text-pure-white dark:text-charcoal-black">21+ views</span>
                </div>
              </div>
              
              <p className="font-cambria text-xs text-pure-white dark:text-charcoal-black leading-tight mt-2">
                Reset when ready
              </p>
            </div>
          </div>
          <button
            onClick={(e) => {
              e.stopPropagation();
              onReset();
            }}
            className="
              bg-pure-white bg-opacity-20 dark:bg-charcoal-black dark:bg-opacity-20 border border-pure-white border-opacity-40 dark:border-charcoal-black dark:border-opacity-60 rounded-luxury p-2.5 sm:p-3
              flex items-center justify-center transition-all duration-300 shadow-soft dark:shadow-dark-soft
              hover:bg-opacity-30 dark:hover:bg-opacity-30 hover:shadow-elegant hover:scale-105
              active:scale-95 min-h-[40px] min-w-[40px] sm:min-h-[44px] sm:min-w-[44px]
              focus:outline-none focus:ring-2 focus:ring-pure-white focus:ring-opacity-50 dark:focus:ring-charcoal-black
            "
          >
            <RotateCcw className="w-4 h-4 text-pure-white dark:text-charcoal-black" />
          </button>
        </div>
      </div>
    </div>
  );
};

export default BorderColorGuide;