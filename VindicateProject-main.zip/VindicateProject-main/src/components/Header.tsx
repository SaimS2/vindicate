import React from 'react';
import MagnifyingGlassLogo from './MagnifyingGlassLogo';

const Header: React.FC = () => {
  return (
    <header className="relative bg-pure-white dark:bg-dark-background border-b border-divider-gray dark:border-dark-divider transition-colors duration-300">
      <div className="container mx-auto px-8 py-8">
        <div className="flex items-center justify-center">
          <div className="flex items-center space-x-8">
            <div className="flex items-center justify-center">
              <MagnifyingGlassLogo size="lg" />
            </div>
            <div className="text-center">
              <h1 className="text-5xl md:text-6xl font-cambria font-bold tracking-spacious mb-2 elegant-text-gradient animate-title-glow">
                VINDICATE
              </h1>
              <p className="text-base text-slate-gray dark:text-dark-text-secondary font-cambria font-normal tracking-wide leading-relaxed">
                Test your Differential Diagnosis Knowledge
              </p>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;