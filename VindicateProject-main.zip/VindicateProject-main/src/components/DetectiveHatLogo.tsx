import React from 'react';

interface DetectiveHatLogoProps {
  size?: 'sm' | 'md' | 'lg' | 'xl';
  className?: string;
}

const DetectiveHatLogo: React.FC<DetectiveHatLogoProps> = ({ size = 'md', className = '' }) => {
  const getSizeClasses = () => {
    switch (size) {
      case 'sm': return 'w-8 h-8';
      case 'md': return 'w-12 h-12';
      case 'lg': return 'w-16 h-16';
      case 'xl': return 'w-20 h-20';
      default: return 'w-12 h-12';
    }
  };

  return (
    <div className={`${getSizeClasses()} ${className} flex items-center justify-center`}>
      <svg 
        viewBox="0 0 140 110" 
        className="w-full h-full"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
      >
        {/* Beautiful Deerstalker Detective Hat */}
        <defs>
          {/* Gradient for depth and luxury */}
          <linearGradient id="hatGradient" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="currentColor" stopOpacity="1" />
            <stop offset="50%" stopColor="currentColor" stopOpacity="0.8" />
            <stop offset="100%" stopColor="currentColor" stopOpacity="0.9" />
          </linearGradient>
          
          {/* Shadow gradient */}
          <linearGradient id="shadowGradient" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="currentColor" stopOpacity="0.3" />
            <stop offset="100%" stopColor="currentColor" stopOpacity="0.1" />
          </linearGradient>
          
          {/* Highlight gradient */}
          <linearGradient id="highlightGradient" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="currentColor" stopOpacity="0.4" />
            <stop offset="100%" stopColor="currentColor" stopOpacity="0.1" />
          </linearGradient>
        </defs>
        
        <g className="text-royal-blue dark:text-white">
          {/* Main Hat Crown - Elegant dome with perfect proportions */}
          <path 
            d="M30 50 C30 32, 42 18, 58 16 C65 15, 75 15, 82 16 C98 18, 110 32, 110 50 C110 56, 107 62, 103 66 L37 66 C33 62, 30 56, 30 50 Z" 
            fill="url(#hatGradient)"
            stroke="currentColor"
            strokeWidth="0.5"
            strokeLinejoin="round"
          />
          
          {/* Crown Center Crease - Sophisticated indentation */}
          <path 
            d="M58 16 C65 20, 70 20, 75 20 C80 20, 85 18, 82 16 C77 24, 72 26, 67 26 C62 26, 57 24, 58 16 Z" 
            fill="url(#shadowGradient)"
          />
          
          {/* Crown Highlight - Adds dimension */}
          <path 
            d="M45 35 C45 28, 50 22, 58 20 C66 22, 75 22, 82 20 C90 22, 95 28, 95 35 C95 38, 93 41, 90 43 L50 43 C47 41, 45 38, 45 35 Z" 
            fill="url(#highlightGradient)"
          />
          
          {/* Front Brim - Gracefully curved */}
          <path 
            d="M22 66 C22 63, 25 60, 30 60 L110 60 C118 60, 125 63, 128 66 C128 71, 125 74, 118 74 L30 74 C25 74, 22 71, 22 66 Z" 
            fill="url(#hatGradient)"
            stroke="currentColor"
            strokeWidth="0.5"
          />
          
          {/* Back Brim - Classic detective hat extension */}
          <path 
            d="M37 66 C34 66, 32 68, 32 71 L32 78 C32 81, 34 84, 37 84 L103 84 C106 84, 108 81, 108 78 L108 71 C108 68, 106 66, 103 66" 
            fill="url(#hatGradient)"
            stroke="currentColor"
            strokeWidth="0.5"
          />
          
          {/* Left Ear Flap - Beautifully shaped */}
          <path 
            d="M30 45 C24 45, 18 47, 14 51 C11 55, 13 60, 17 63 C21 66, 26 65, 30 61 L30 45 Z" 
            fill="url(#hatGradient)"
            stroke="currentColor"
            strokeWidth="0.5"
            strokeLinejoin="round"
          />
          
          {/* Right Ear Flap - Perfectly mirrored */}
          <path 
            d="M110 45 C116 45, 122 47, 126 51 C129 55, 127 60, 123 63 C119 66, 114 65, 110 61 L110 45 Z" 
            fill="url(#hatGradient)"
            stroke="currentColor"
            strokeWidth="0.5"
            strokeLinejoin="round"
          />
          
          {/* Elegant Ear Flap Ties */}
          <path 
            d="M17 63 C15 65, 14 68, 15 71 C16 74, 18 75, 20 74" 
            stroke="currentColor" 
            strokeWidth="2" 
            strokeLinecap="round"
            fill="none"
          />
          <path 
            d="M123 63 C125 65, 126 68, 125 71 C124 74, 122 75, 120 74" 
            stroke="currentColor" 
            strokeWidth="2" 
            strokeLinecap="round"
            fill="none"
          />
          
          {/* Sophisticated Hat Band */}
          <rect 
            x="35" 
            y="56" 
            width="70" 
            height="6" 
            rx="3" 
            fill="url(#shadowGradient)"
          />
          
          {/* Hat Band Decorative Buckle */}
          <rect 
            x="92" 
            y="57" 
            width="8" 
            height="4" 
            rx="2" 
            fill="currentColor"
            fillOpacity="0.7"
          />
          <rect 
            x="93" 
            y="58" 
            width="6" 
            height="2" 
            rx="1" 
            fill="none" 
            stroke="currentColor" 
            strokeWidth="0.5"
            strokeOpacity="0.5"
          />
          
          {/* Crown Top Button - Refined detail */}
          <circle 
            cx="70" 
            cy="28" 
            r="2.5" 
            fill="url(#shadowGradient)"
          />
          <circle 
            cx="70" 
            cy="27" 
            r="1.5" 
            fill="currentColor"
            fillOpacity="0.4"
          />
          
          {/* Subtle Crown Stitching Lines */}
          <path 
            d="M45 40 C55 38, 65 38, 75 38 C85 38, 95 40, 95 40" 
            stroke="currentColor" 
            strokeWidth="0.5" 
            strokeOpacity="0.3"
            fill="none"
            strokeDasharray="2,2"
          />
          
          {/* Brim Edge Highlight */}
          <path 
            d="M30 60 C35 58, 45 58, 70 58 C95 58, 105 58, 110 60" 
            stroke="currentColor" 
            strokeWidth="1" 
            strokeOpacity="0.2"
            fill="none"
          />
          
          {/* Additional Crown Shading for Depth */}
          <ellipse 
            cx="70" 
            cy="45" 
            rx="25" 
            ry="15" 
            fill="url(#shadowGradient)"
            opacity="0.2"
          />
          
          {/* Ear Flap Interior Details */}
          <path 
            d="M26 50 C24 52, 24 55, 26 57" 
            stroke="currentColor" 
            strokeWidth="0.5" 
            strokeOpacity="0.4"
            fill="none"
          />
          <path 
            d="M114 50 C116 52, 116 55, 114 57" 
            stroke="currentColor" 
            strokeWidth="0.5" 
            strokeOpacity="0.4"
            fill="none"
          />
        </g>
      </svg>
    </div>
  );
};

export default DetectiveHatLogo;