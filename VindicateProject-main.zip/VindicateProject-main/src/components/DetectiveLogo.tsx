import React from 'react';

interface DetectiveLogoProps {
  size?: 'sm' | 'md' | 'lg' | 'xl';
  className?: string;
}

const DetectiveLogo: React.FC<DetectiveLogoProps> = ({ size = 'md', className = '' }) => {
  const getSizeClasses = () => {
    switch (size) {
      case 'sm': return 'w-8 h-8';
      case 'md': return 'w-12 h-12';
      case 'lg': return 'w-16 h-16';
      case 'xl': return 'w-20 h-20';
      default: return 'w-12 h-12';
    }
  };

  return (
    <div className={`${getSizeClasses()} ${className} flex items-center justify-center`}>
      <svg 
        viewBox="0 0 120 100" 
        className="w-full h-full"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
      >
        {/* Fedora Hat Side Profile */}
        <g fill="#0B2545">
          {/* Main Hat Crown - Classic Fedora Shape */}
          <path d="M20 50 C20 35, 30 25, 45 25 C55 22, 65 22, 75 25 C90 25, 100 35, 100 50 C100 55, 98 60, 95 62 L25 62 C22 60, 20 55, 20 50 Z" />
          
          {/* Hat Crease/Center Dent */}
          <path d="M45 25 C50 28, 55 28, 60 28 C65 28, 70 26, 75 25 C70 30, 65 32, 60 32 C55 32, 50 30, 45 25 Z" fill="#0B2545" opacity="0.3" />
          
          {/* Hat Brim - Extended and Curved */}
          <path d="M15 62 C15 60, 17 58, 20 58 L100 58 C105 58, 110 60, 112 62 C112 66, 110 68, 105 68 L20 68 C17 68, 15 66, 15 62 Z" />
          
          {/* Brim Shadow/Depth */}
          <path d="M15 65 C15 63, 17 62, 20 62 L100 62 C105 62, 110 63, 112 65 C110 67, 105 68, 100 68 L20 68 C17 68, 15 67, 15 65 Z" fill="#0B2545" opacity="0.4" />
          
          {/* Hat Band */}
          <rect x="22" y="55" width="76" height="7" rx="3" />
          
          {/* Hat Band Detail/Buckle */}
          <rect x="85" y="56" width="8" height="5" rx="1" fill="#0B2545" opacity="0.8" />
          <rect x="86" y="57" width="6" height="3" rx="0.5" fill="none" stroke="#0B2545" strokeWidth="0.5" opacity="0.6" />
        </g>
      </svg>
    </div>
  );
};

export default DetectiveLogo;