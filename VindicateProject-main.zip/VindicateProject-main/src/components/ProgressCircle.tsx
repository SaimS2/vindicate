import React from 'react';

interface ProgressCircleProps {
  count: number;
  size?: 'sm' | 'md' | 'lg';
  className?: string;
}

const ProgressCircle: React.FC<ProgressCircleProps> = ({ 
  count, 
  size = 'sm', 
  className = '' 
}) => {
  const getSizeClasses = () => {
    switch (size) {
      case 'sm': return { container: 'w-4 h-4', circle: 12, stroke: 1.5 };
      case 'md': return { container: 'w-6 h-6', circle: 18, stroke: 2 };
      case 'lg': return { container: 'w-8 h-8', circle: 24, stroke: 2.5 };
      default: return { container: 'w-4 h-4', circle: 12, stroke: 1.5 };
    }
  };

  const { container, circle, stroke } = getSizeClasses();
  const radius = (circle - stroke) / 2;
  const circumference = radius * 2 * Math.PI;
  
  // Calculate progress: 0-14 interactions = red, 15-29 = yellow, 30+ = green
  const getProgress = () => {
    if (count >= 30) {
      // Green phase: gradually fill from 0 to 100% over interactions 30-44
      const greenPercent = Math.min(((count - 30) / 14) * 100, 100);
      return { percent: greenPercent, color: '#22C55E', bgColor: '#22C55E20' }; // Green
    }
    if (count >= 15) {
      // Yellow phase: gradually fill from 0 to 100% over interactions 15-29
      const yellowPercent = Math.min(((count - 15) / 14) * 100, 100);
      return { percent: yellowPercent, color: '#EAB308', bgColor: '#EAB30820' }; // Yellow
    }
    
    // Red phase: gradually fill from 0 to 100% over 14 interactions
    const redPercent = Math.min((count / 14) * 100, 100);
    return { percent: redPercent, color: '#DC2626', bgColor: '#DC262620' }; // Red
  };

  const { percent, color, bgColor } = getProgress();
  const strokeDasharray = `${(percent / 100) * circumference} ${circumference}`;

  return (
    <div className={`${container} ${className} relative flex items-center justify-center`}>
      <svg
        className="transform -rotate-90"
        width={circle}
        height={circle}
        viewBox={`0 0 ${circle} ${circle}`}
      >
        {/* Background circle */}
        <circle
          cx={circle / 2}
          cy={circle / 2}
          r={radius}
          stroke="currentColor"
          strokeWidth={stroke}
          fill="none"
          className="text-gray-300 dark:text-gray-600"
          opacity={0.3}
        />
        
        {/* Progress circle */}
        <circle
          cx={circle / 2}
          cy={circle / 2}
          r={radius}
          stroke={color}
          strokeWidth={stroke}
          fill="none"
          strokeDasharray={strokeDasharray}
          strokeLinecap="round"
          className="transition-all duration-500 ease-out"
          style={{
            filter: `drop-shadow(0 0 2px ${color}40)`
          }}
        />
        
        {/* Center dot when fully filled */}
        {percent === 100 && (
          <circle
            cx={circle / 2}
            cy={circle / 2}
            r={radius * 0.3}
            fill={color}
            className="animate-pulse"
          />
        )}
      </svg>
    </div>
  );
};

export default ProgressCircle;