import React from 'react';

interface MagnifyingGlassLogoProps {
  size?: 'sm' | 'md' | 'lg' | 'xl';
  className?: string;
}

const MagnifyingGlassLogo: React.FC<MagnifyingGlassLogoProps> = ({ size = 'md', className = '' }) => {
  const getSizeClasses = () => {
    switch (size) {
      case 'sm': return 'w-8 h-8';
      case 'md': return 'w-12 h-12';
      case 'lg': return 'w-16 h-16';
      case 'xl': return 'w-20 h-20';
      default: return 'w-12 h-12';
    }
  };

  return (
    <div className={`${getSizeClasses()} ${className} flex items-center justify-center`}>
      <svg 
        viewBox="0 0 100 100" 
        className="w-full h-full"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
      >
        {/* Main Lens - Thick cartoon style */}
        <circle 
          cx="35" 
          cy="35" 
          r="25" 
          stroke="currentColor" 
          strokeWidth="6"
          fill="none"
          strokeLinecap="round"
          className="text-royal-blue dark:text-white"
        />
        
        {/* Handle - straight and thick like cartoon style */}
        <line 
          x1="55" 
          y1="55" 
          x2="80" 
          y2="80" 
          stroke="currentColor" 
          strokeWidth="8" 
          strokeLinecap="round"
          className="text-royal-blue dark:text-white"
        />
        
        {/* Handle end cap - rounded cartoon style */}
        <circle 
          cx="80" 
          cy="80" 
          r="4" 
          fill="currentColor"
          className="text-royal-blue dark:text-white"
        />
        
        {/* Simple grip lines on handle */}
        <line 
          x1="60" 
          y1="60" 
          x2="62" 
          y2="62" 
          stroke="currentColor" 
          strokeWidth="3" 
          strokeLinecap="round"
          opacity="0.7"
          className="text-royal-blue dark:text-white"
        />
        <line 
          x1="65" 
          y1="65" 
          x2="67" 
          y2="67" 
          stroke="currentColor" 
          strokeWidth="3" 
          strokeLinecap="round"
          opacity="0.7"
          className="text-royal-blue dark:text-white"
        />
        <line 
          x1="70" 
          y1="70" 
          x2="72" 
          y2="72" 
          stroke="currentColor" 
          strokeWidth="3" 
          strokeLinecap="round"
          opacity="0.7"
          className="text-royal-blue dark:text-white"
        />
      </svg>
    </div>
  );
};

export default MagnifyingGlassLogo;