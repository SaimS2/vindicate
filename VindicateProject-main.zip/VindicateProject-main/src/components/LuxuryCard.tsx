import React, { ReactNode } from 'react';

interface LuxuryCardProps {
  children: ReactNode;
  onClick?: () => void;
  disabled?: boolean;
  className?: string;
  clickCount?: number;
  colorScheme?: string;
}

const LuxuryCard: React.FC<LuxuryCardProps> = ({
  children,
  onClick,
  disabled = false,
  className = '',
  clickCount = 0,
  colorScheme = 'burgundy'
}) => {
  const getGlowClass = () => {
    if (disabled) return 'border border-light-gray dark:border-white shadow-soft dark:shadow-dark-soft rounded-luxury opacity-60 dark:opacity-70';
    return 'border border-light-gray dark:border-white hover:royal-blue-hover-glow hover:border-royal-blue hover:border-opacity-60 dark:hover:border-white';
  };

  const baseClasses = `
    bg-soft-gray dark:bg-dark-surface-elevated rounded-luxury transition-all duration-300 ease-out
    transform cursor-pointer relative overflow-hidden min-h-[44px]
    shadow-luxury-soft dark:shadow-dark-luxury-soft focus:outline-none focus:ring-2 focus:ring-royal-blue focus:ring-opacity-50
  `;

  const activeClasses = `
    active:scale-95 hover:animate-micro-pulse
  `;

  const disabledClasses = `
    cursor-not-allowed hover:scale-100 hover:border-light-gray dark:hover:border-white
    hover:shadow-soft dark:hover:shadow-dark-soft hover:bg-soft-gray dark:hover:bg-dark-surface-elevated
  `;

  return (
    <div
      className={`${baseClasses} ${disabled ? disabledClasses : activeClasses} ${getGlowClass()} ${className}`}
      onClick={disabled ? undefined : onClick}
      tabIndex={disabled ? -1 : 0}
      role="button"
      onKeyDown={(e) => {
        if (!disabled && (e.key === 'Enter' || e.key === ' ')) {
          e.preventDefault();
          onClick?.();
        }
      }}
    >
      {children}
    </div>
  );
};

export default LuxuryCard;