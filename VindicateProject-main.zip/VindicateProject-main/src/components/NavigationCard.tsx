import React, { ReactNode } from 'react';

interface NavigationCardProps {
  children: ReactNode;
  onClick?: () => void;
  disabled?: boolean;
  className?: string;
  glowColor?: string;
}

const NavigationCard: React.FC<NavigationCardProps> = ({
  children,
  onClick,
  disabled = false,
  className = '',
  glowColor = 'elegant-gold'
}) => {
  const baseClasses = `
    bg-card rounded-3xl border border-gray-700 transition-all duration-700
    transform hover:scale-[1.02] cursor-pointer relative overflow-hidden
    backdrop-blur-sm shadow-luxury glass-effect
  `;

  const activeClasses = `
    hover:border-accent-gold hover:shadow-elegant-gold
    active:scale-[0.98] hover:bg-gradient-to-br hover:from-gray-800 hover:to-gray-900
    hover:shadow-inner-glow
  `;

  const disabledClasses = `
    opacity-30 cursor-not-allowed hover:scale-100 hover:border-gray-700
    hover:bg-card hover:shadow-luxury
  `;

  return (
    <div
      className={`${baseClasses} ${disabled ? disabledClasses : activeClasses} ${className}`}
      onClick={disabled ? undefined : onClick}
    >
      {children}
      {disabled && (
        <div className="absolute inset-0 flex items-center justify-center bg-black bg-opacity-60 rounded-3xl backdrop-blur-sm">
          <div className="text-center">
            <div className="w-10 h-10 mx-auto mb-4 rounded-full border-2 border-accent-silver border-t-transparent animate-spin"></div>
            <span className="text-accent-silver font-playfair text-sm tracking-wider font-medium">
              Coming Soon
            </span>
          </div>
        </div>
      )}
    </div>
  );
};

export default NavigationCard;