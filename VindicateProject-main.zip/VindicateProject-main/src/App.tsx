import React, { useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, useLocation } from 'react-router-dom';
import { ThemeProvider } from './contexts/ThemeContext';
import NavigationBar from './components/NavigationBar';
import DarkModeToggle from './components/DarkModeToggle';
import LandingPage from './pages/LandingPage';
import AgeCategories from './pages/AgeCategories';
import AdultSystems from './pages/AdultSystems';
import CardiovascularPresentations from './pages/CardiovascularPresentations';
import VindicateFramework from './pages/VindicateFramework';
import RevealDifferentials from './pages/RevealDifferentials';

function ScrollToTop() {
  const { pathname } = useLocation();

  useEffect(() => {
    window.scrollTo(0, 0);
  }, [pathname]);

  return null;
}

function AppContent() {
  const location = useLocation();
  const isLandingPage = location.pathname === '/';

  return (
    <div className="min-h-screen bg-pure-white dark:bg-dark-background text-charcoal-black dark:text-dark-text font-cambria transition-colors duration-300">
      <ScrollToTop />
      <DarkModeToggle />
      {!isLandingPage && <NavigationBar />}
      <main className={`${!isLandingPage ? 'pt-20' : ''} transition-opacity duration-300 ease-out`}>
        <div className="page-enter-active">
          <Routes>
            <Route path="/" element={<LandingPage />} />
            <Route path="/age-categories" element={<AgeCategories />} />
            <Route path="/adult-systems" element={<AdultSystems />} />
            <Route path="/cardiovascular-presentations" element={<CardiovascularPresentations />} />
            <Route path="/vindicate-framework" element={<VindicateFramework />} />
            <Route path="/reveal-differentials/:category" element={<RevealDifferentials />} />
          </Routes>
        </div>
      </main>
    </div>
  );
}

function App() {
  return (
    <ThemeProvider>
      <Router>
        <AppContent />
      </Router>
    </ThemeProvider>
  );
}

export default App;