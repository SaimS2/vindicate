import React from 'react';
import { useNavigate } from 'react-router-dom';
import MagnifyingGlassLogo from '../components/MagnifyingGlassLogo';

const LandingPage: React.FC = () => {
  const navigate = useNavigate();

  const handleGetStarted = () => {
    navigate('/age-categories');
  };

  return (
    <div className="min-h-screen bg-pure-white dark:bg-dark-background transition-colors duration-300 flex flex-col items-center justify-center px-4 sm:px-6 lg:px-8">
      <div className="text-center max-w-md w-full">
        {/* Logo and Title */}
        <div className="flex flex-col items-center space-y-8 mb-12">
          <div className="flex items-center justify-center">
            <MagnifyingGlassLogo size="xl" />
          </div>
          
          <div className="space-y-4">
            <h1 className="text-4xl sm:text-5xl md:text-6xl font-cambria font-normal tracking-wide mb-2 elegant-text-gradient animate-title-glow">
              VINDICATE
            </h1>
            <p className="text-base sm:text-lg text-royal-blue dark:text-white font-cambria font-normal tracking-wide leading-relaxed px-4">
              Test your Differential Diagnosis Knowledge
            </p>
          </div>
        </div>

        {/* Get Started Button */}
        <button
          onClick={handleGetStarted}
          className="
            w-full max-w-xs mx-auto py-4 px-8 rounded-luxury
            bg-soft-gray dark:bg-dark-surface-elevated border-2 border-royal-blue border-opacity-60 dark:border-white
            transition-all duration-300 shadow-luxury-soft dark:shadow-dark-luxury-soft
            hover:royal-blue-hover-glow hover:border-royal-blue hover:border-opacity-80 dark:hover:border-white
            active:scale-95 min-h-[56px]
            focus:outline-none focus:ring-2 focus:ring-royal-blue focus:ring-opacity-50
          "
        >
          <span className="text-lg font-cambria font-semibold tracking-elegant text-royal-blue dark:text-white leading-tight">
            Get Started
          </span>
        </button>
      </div>
    </div>
  );
};

export default LandingPage;