import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Baby, Users, Stethoscope, UserCheck, HeartPulse } from 'lucide-react';
import LuxuryCard from '../components/LuxuryCard';

const AgeCategories: React.FC = () => {
  const navigate = useNavigate();
  const [clickCounts, setClickCounts] = useState<Record<string, number>>({});

  const categories = [
    { 
      id: 'neonate', 
      name: 'Neonate', 
      icon: Baby, 
      disabled: true,
      description: 'Birth to 28 days',
      colorScheme: 'burgundy' as const
    },
    { 
      id: 'pediatrics', 
      name: 'Pediatrics', 
      icon: Users, 
      disabled: true,
      description: '28 days to 18 years',
      colorScheme: 'slate-blue' as const
    },
    { 
      id: 'adult', 
      name: 'Adult', 
      icon: Stethoscope, 
      disabled: false,
      description: '18 to 65 years',
      colorScheme: 'burgundy' as const
    },
    { 
      id: 'geriatrics', 
      name: 'Geriatrics', 
      icon: UserCheck, 
      disabled: true,
      description: '65+ years',
      colorScheme: 'olive-green' as const
    },
    { 
      id: 'obstetrics', 
      name: 'Obstetrics', 
      icon: HeartPulse, 
      disabled: false,
      description: 'Pregnancy & Birth',
      colorScheme: 'dusty-rose' as const
    }
  ];

  const handleCategoryClick = (categoryId: string) => {
    if (categoryId === 'adult' || categoryId === 'obstetrics') {
      setClickCounts(prev => ({
        ...prev,
        [categoryId]: (prev[categoryId] || 0) + 1
      }));
      navigate('/adult-systems');
    }
    // For disabled categories (neonate, pediatrics, geriatrics), do nothing
  };

  return (
    <div className="min-h-screen py-16 sm:py-20 px-6 sm:px-6 bg-pure-white dark:bg-dark-background transition-colors duration-300 flex flex-col items-center justify-center">
      <div className="container mx-auto max-w-xs w-full">
        <div className="text-center mb-12 sm:mb-16">
          <h2 className="text-lg sm:text-xl font-cambria font-normal mb-4 tracking-wide text-royal-blue dark:text-white leading-relaxed">
            Pick a Patient Demographic
          </h2>
        </div>

        <div className="flex flex-col space-y-4 w-full">
          {categories.map((category, index) => {
            const IconComponent = category.icon;
            return (
              <div key={category.id} className="flex justify-center">
                <LuxuryCard
                  onClick={() => handleCategoryClick(category.id)}
                  disabled={category.disabled}
                  colorScheme={category.colorScheme}
                  clickCount={clickCounts[category.id] || 0}
                  className="flex items-center justify-center py-3 sm:py-3 px-4 sm:px-4 rounded-luxury w-full min-h-[52px] sm:min-h-[56px]"
                >
                  <div className="flex flex-col items-center justify-center space-y-3 text-center w-full">
                    <IconComponent className="w-4 h-4 sm:w-5 sm:h-5 text-royal-blue dark:text-white" />
                    <div className="space-y-1">
                      <h3 className="text-xs font-cambria font-normal tracking-elegant text-royal-blue dark:text-white leading-tight">
                        {category.name}
                      </h3>
                      <p className="text-xs text-royal-blue dark:text-white font-cambria font-normal leading-relaxed opacity-70 dark:opacity-80">
                        {category.description}
                      </p>
                    </div>
                  </div>
                </LuxuryCard>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};

export default AgeCategories;