import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  GitBranch, 
  Flame, 
  Target, 
  TrendingDown, 
  HelpCircle, 
  Baby, 
  Shield, 
  Zap, 
  Atom
} from 'lucide-react';
import ToggleControls from '../components/ToggleControls';

const VindicateFramework: React.FC = () => {
  const navigate = useNavigate();
  const [currentPresentation, setCurrentPresentation] = useState<string>('');
  
  // Toggle control states
  const [chronicity, setChronicity] = useState<number>(24); // Default to 1 day
  const [biologicalSex, setBiologicalSex] = useState<'male' | 'female'>('male');
  const [age, setAge] = useState<number>(45); // Default middle age

  // Get age range based on current category or default to adult
  const getAgeRange = () => {
    // This could be enhanced to get the actual selected demographic from localStorage
    // For now, defaulting to adult range
    return { min: 18, max: 65 };
  };

  // Load the current presentation from localStorage
  useEffect(() => {
    const presentation = localStorage.getItem('current-presentation');
    if (presentation) {
      setCurrentPresentation(presentation.toUpperCase());
    } else {
      setCurrentPresentation('CHEST PAIN'); // Default fallback
    }
  }, []);

  const categories = [
    { 
      id: 'vascular', 
      name: 'Vascular', 
      icon: GitBranch, 
      disabled: false,
      colorScheme: 'burgundy' as const
    },
    { 
      id: 'infectious', 
      name: 'Infectious', 
      icon: Flame, 
      disabled: false,
      colorScheme: 'slate-blue' as const
    },
    { 
      id: 'neoplastic', 
      name: 'Neoplastic', 
      icon: Target, 
      disabled: false,
      colorScheme: 'olive-green' as const
    },
    { 
      id: 'degenerative', 
      name: 'Degenerative', 
      icon: TrendingDown, 
      disabled: false,
      colorScheme: 'dusty-rose' as const
    },
    { 
      id: 'idiopathic', 
      name: 'Idiopathic', 
      icon: HelpCircle, 
      disabled: false,
      colorScheme: 'gold-accent' as const
    },
    { 
      id: 'congenital', 
      name: 'Congenital', 
      icon: Baby, 
      disabled: false,
      colorScheme: 'slate-blue' as const
    },
    { 
      id: 'autoimmune', 
      name: 'Autoimmune', 
      icon: Shield, 
      disabled: false,
      colorScheme: 'olive-green' as const
    },
    { 
      id: 'traumatic', 
      name: 'Traumatic', 
      icon: Zap, 
      disabled: false,
      colorScheme: 'dusty-rose' as const
    },
    { 
      id: 'endocrine', 
      name: 'Endocrine', 
      icon: Atom, 
      disabled: false,
      colorScheme: 'burgundy' as const
    }
  ];

  const handleCategoryClick = (categoryId: string) => {
    navigate(`/reveal-differentials/${categoryId}`);
  };

  return (
    <div className="min-h-screen py-16 sm:py-20 px-6 sm:px-6 bg-pure-white dark:bg-dark-background transition-colors duration-300 flex flex-col items-center justify-center">
      <div className="container mx-auto max-w-xs w-full">
        <div className="text-center mb-8 sm:mb-12">
          {/* Dynamic Presentation Header */}
          <div className="mb-6 px-4 py-3 border-2 border-royal-blue dark:border-white rounded-luxury bg-soft-gray dark:bg-dark-surface-elevated shadow-luxury-soft dark:shadow-dark-luxury-soft">
            <h1 className="text-lg sm:text-xl font-cambria font-normal text-royal-blue dark:text-white tracking-wide leading-relaxed">
              {currentPresentation}
            </h1>
          </div>
          
          <p className="text-xs text-royal-blue dark:text-white font-cambria font-normal leading-relaxed px-4">
            Select a category to test your knowledge
          </p>
        </div>

        {/* Toggle Controls */}
        <ToggleControls
          chronicity={chronicity}
          onChronicityChange={setChronicity}
          biologicalSex={biologicalSex}
          onBiologicalSexChange={setBiologicalSex}
          age={age}
          onAgeChange={setAge}
          ageRange={getAgeRange()}
        />

        <div className="flex flex-col space-y-4 w-full">
          {categories.map((category) => {
            const IconComponent = category.icon;
            
            return (
              <div key={category.id} className="flex justify-center">
                <button
                  onClick={() => handleCategoryClick(category.id)}
                  className={`
                    w-full flex items-center justify-center py-4 sm:py-4 px-6 sm:px-5 rounded-luxury
                    bg-soft-gray dark:bg-dark-surface-elevated transition-all duration-300 
                    min-h-[60px] sm:min-h-[60px] shadow-luxury-soft dark:shadow-dark-luxury-soft
                    border border-light-gray dark:border-white hover:royal-blue-hover-glow hover:border-royal-blue hover:border-opacity-60 dark:hover:border-white
                    focus:outline-none focus:ring-2 focus:ring-royal-blue focus:ring-opacity-50
                    active:scale-95
                  `}
                >
                  <div className="flex items-center space-x-3 sm:space-x-4">
                    <IconComponent className="w-4 h-4 sm:w-5 sm:h-5 text-royal-blue dark:text-white flex-shrink-0" />
                    <span className="text-xs font-cambria font-normal tracking-elegant text-royal-blue dark:text-white leading-tight">
                      {category.name}
                    </span>
                  </div>
                </button>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};

export default VindicateFramework;