import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  Zap, 
  Activity, 
  Wind, 
  CircleOff, 
  Waves, 
  Battery, 
  Thermometer, 
  Radio, 
  Palette 
} from 'lucide-react';

const CardiovascularPresentations: React.FC = () => {
  const navigate = useNavigate();
  const [clickCounts, setClickCounts] = useState<Record<string, number>>({});

  // Load click counts from localStorage on component mount
  React.useEffect(() => {
    const savedClickCounts = localStorage.getItem('vindicate-presentation-click-counts');
    if (savedClickCounts) {
      try {
        const parsed = JSON.parse(savedClickCounts);
        setClickCounts(parsed);
      } catch (error) {
        console.error('Error loading click counts from localStorage:', error);
      }
    }
  }, []);

  // Save click counts to localStorage whenever they change
  React.useEffect(() => {
    localStorage.setItem('vindicate-presentation-click-counts', JSON.stringify(clickCounts));
  }, [clickCounts]);

  const presentations = [
    { 
      id: 'chest-pain', 
      name: 'Chest Pain', 
      icon: Zap, 
      disabled: false,
      colorScheme: 'burgundy' as const
    },
    { 
      id: 'palpitations', 
      name: 'Palpitations', 
      icon: Activity, 
      disabled: true,
      colorScheme: 'slate-blue' as const
    },
    { 
      id: 'dyspnea', 
      name: 'Dyspnea', 
      icon: Wind, 
      disabled: true,
      colorScheme: 'olive-green' as const
    },
    { 
      id: 'syncope', 
      name: 'Syncope', 
      icon: CircleOff, 
      disabled: true,
      colorScheme: 'dusty-rose' as const
    },
    { 
      id: 'edema', 
      name: 'Edema', 
      icon: Waves, 
      disabled: true,
      colorScheme: 'gold-accent' as const
    },
    { 
      id: 'fatigue', 
      name: 'Fatigue', 
      icon: Battery, 
      disabled: true,
      colorScheme: 'slate-blue' as const
    },
    { 
      id: 'cough', 
      name: 'Cough', 
      icon: Thermometer, 
      disabled: true,
      colorScheme: 'olive-green' as const
    },
    { 
      id: 'murmurs', 
      name: 'Heart Murmurs', 
      icon: Radio, 
      disabled: true,
      colorScheme: 'dusty-rose' as const
    },
    { 
      id: 'cyanosis', 
      name: 'Cyanosis', 
      icon: Palette, 
      disabled: true,
      colorScheme: 'burgundy' as const
    }
  ];

  const handlePresentationClick = (presentationId: string) => {
    if (presentationId === 'chest-pain') {
      setClickCounts(prev => ({
        ...prev,
        [presentationId]: (prev[presentationId] || 0) + 1
      }));
      navigate('/vindicate-framework');
    }
  };

  return (
    <div className="min-h-screen py-16 sm:py-20 px-6 sm:px-6 bg-pure-white dark:bg-dark-background transition-colors duration-300 flex flex-col items-center justify-center">
      <div className="container mx-auto max-w-xs w-full">
        <div className="text-center mb-12 sm:mb-16">
          <h2 className="text-lg sm:text-xl font-cambria font-normal mb-4 tracking-wide text-royal-blue dark:text-white leading-relaxed">
            CLINICAL
          </h2>
          <h3 className="text-lg sm:text-xl font-cambria font-normal mb-4 tracking-wide text-royal-blue dark:text-white leading-relaxed -mt-2">
            PRESENTATIONS
          </h3>
        </div>

        <div className="flex flex-col space-y-4 w-full">
          {presentations.map((presentation, index) => {
            const IconComponent = presentation.icon;
            return (
              <div key={presentation.id} className="flex justify-center">
                <div className="w-full relative">
                  <button
                    onClick={() => handlePresentationClick(presentation.id)}
                    disabled={presentation.disabled}
                    className={`
                      w-full flex items-center justify-center space-x-3 sm:space-x-4 py-4 sm:py-4 px-6 sm:px-5 rounded-luxury
                      bg-soft-gray dark:bg-dark-surface-elevated transition-all duration-300 min-h-[60px] sm:min-h-[60px] shadow-luxury-soft dark:shadow-dark-luxury-soft
                      border border-light-gray dark:border-white hover:royal-blue-hover-glow hover:border-royal-blue hover:border-opacity-60 dark:hover:border-white
                      focus:outline-none focus:ring-2 focus:ring-royal-blue focus:ring-opacity-50
                      ${presentation.disabled ? 'cursor-not-allowed' : 'active:scale-95'}
                    `}
                  >
                    <IconComponent className="w-4 h-4 sm:w-5 sm:h-5 text-royal-blue dark:text-white flex-shrink-0" />
                    <span className="text-xs font-cambria font-normal tracking-elegant text-royal-blue dark:text-white leading-tight text-center flex-1">
                      {presentation.name}
                    </span>
                  </button>
                  
                  {presentation.disabled && (
                    <div className="absolute inset-0 bg-pure-white dark:bg-dark-background bg-opacity-40 dark:bg-opacity-40 rounded-luxury backdrop-blur-sm">
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};

export default CardiovascularPresentations;