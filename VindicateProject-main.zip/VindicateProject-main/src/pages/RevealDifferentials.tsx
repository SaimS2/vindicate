import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import RevealTile from '../components/RevealTile';
import ToggleControls from '../components/ToggleControls';

const RevealDifferentials: React.FC = () => {
  const { category } = useParams<{ category: string }>();
  const [currentPresentation, setCurrentPresentation] = useState<string>('');
  const [revealedStates, setRevealedStates] = useState<Record<string, boolean>>({});
  const [clickCounts, setClickCounts] = useState<Record<string, number>>({});
  
  // Toggle control states
  const [chronicity, setChronicity] = useState<number>(24); // Default to 1 day
  const [biologicalSex, setBiologicalSex] = useState<'male' | 'female'>('male');
  const [age, setAge] = useState<number>(45); // Default middle age

  // Get age range based on current category or default to adult
  const getAgeRange = () => {
    // This could be enhanced to get the actual selected demographic from localStorage
    // For now, defaulting to adult range
    return { min: 18, max: 65 };
  };

  // Load the current presentation from localStorage
  useEffect(() => {
    const presentation = localStorage.getItem('current-presentation');
    if (presentation) {
      setCurrentPresentation(presentation.toUpperCase());
    } else {
      setCurrentPresentation('CHEST PAIN'); // Default fallback
    }
  }, []);

  // Load click counts and revealed states from localStorage
  useEffect(() => {
    const savedClickCounts = localStorage.getItem(`vindicate-${category}-click-counts`);
    const savedRevealedStates = localStorage.getItem(`vindicate-${category}-revealed-states`);
    
    if (savedClickCounts) {
      try {
        setClickCounts(JSON.parse(savedClickCounts));
      } catch (error) {
        console.error('Error loading click counts:', error);
      }
    }
    
    if (savedRevealedStates) {
      try {
        setRevealedStates(JSON.parse(savedRevealedStates));
      } catch (error) {
        console.error('Error loading revealed states:', error);
      }
    }
  }, [category]);

  // Save states to localStorage whenever they change
  useEffect(() => {
    localStorage.setItem(`vindicate-${category}-click-counts`, JSON.stringify(clickCounts));
  }, [clickCounts, category]);

  useEffect(() => {
    localStorage.setItem(`vindicate-${category}-revealed-states`, JSON.stringify(revealedStates));
  }, [revealedStates, category]);

  const handleReset = () => {
    setClickCounts({});
    setRevealedStates({});
    localStorage.removeItem(`vindicate-${category}-click-counts`);
    localStorage.removeItem(`vindicate-${category}-revealed-states`);
  };

  const handleReveal = (diagnosisId: string) => {
    setRevealedStates(prev => ({
      ...prev,
      [diagnosisId]: true
    }));
    
    setClickCounts(prev => ({
      ...prev,
      [diagnosisId]: (prev[diagnosisId] || 0) + 1
    }));
  };

  const handleHide = (diagnosisId: string) => {
    setRevealedStates(prev => ({
      ...prev,
      [diagnosisId]: false
    }));
  };

  // Get category display name
  const getCategoryDisplayName = () => {
    const categoryNames: Record<string, string> = {
      'vascular': 'VASCULAR',
      'infectious': 'INFECTIOUS', 
      'neoplastic': 'NEOPLASTIC',
      'degenerative': 'DEGENERATIVE',
      'idiopathic': 'IDIOPATHIC',
      'congenital': 'CONGENITAL',
      'autoimmune': 'AUTOIMMUNE',
      'traumatic': 'TRAUMATIC',
      'endocrine': 'ENDOCRINE'
    };
    return categoryNames[category || ''] || 'UNKNOWN';
  };

  // Comprehensive differential diagnoses for each category
  const getDifferentials = () => {
    const presentation = currentPresentation.toLowerCase();
    
    // Define differentials based on presentation and category
    const differentials: Record<string, Record<string, Array<{ diagnosis: string; isDangerous?: boolean }>>> = {
      'chest pain': {
        vascular: [
          { diagnosis: 'Myocardial Infarction', isDangerous: true },
          { diagnosis: 'Unstable Angina', isDangerous: true },
          { diagnosis: 'Aortic Dissection', isDangerous: true },
          { diagnosis: 'Pulmonary Embolism', isDangerous: true },
          { diagnosis: 'Stable Angina' },
          { diagnosis: 'Peripheral Vascular Disease' },
          { diagnosis: 'Aortic Stenosis' },
          { diagnosis: 'Hypertensive Emergency', isDangerous: true }
        ],
        infectious: [
          { diagnosis: 'Pericarditis' },
          { diagnosis: 'Myocarditis' },
          { diagnosis: 'Pneumonia' },
          { diagnosis: 'Pleuritis' },
          { diagnosis: 'Endocarditis' },
          { diagnosis: 'Mediastinitis', isDangerous: true },
          { diagnosis: 'Empyema' },
          { diagnosis: 'Lung Abscess' }
        ],
        neoplastic: [
          { diagnosis: 'Lung Cancer' },
          { diagnosis: 'Mesothelioma' },
          { diagnosis: 'Mediastinal Mass' },
          { diagnosis: 'Chest Wall Tumor' },
          { diagnosis: 'Metastatic Disease' },
          { diagnosis: 'Lymphoma' },
          { diagnosis: 'Thymoma' }
        ],
        degenerative: [
          { diagnosis: 'Osteoarthritis of Spine' },
          { diagnosis: 'Degenerative Disc Disease' },
          { diagnosis: 'Costochondritis' },
          { diagnosis: 'Fibromyalgia' },
          { diagnosis: 'Tietze Syndrome' },
          { diagnosis: 'Intercostal Neuralgia' }
        ],
        idiopathic: [
          { diagnosis: 'Atypical Chest Pain' },
          { diagnosis: 'Idiopathic Pericarditis' },
          { diagnosis: 'Non-specific Chest Pain' },
          { diagnosis: 'Precordial Catch Syndrome' }
        ],
        congenital: [
          { diagnosis: 'Hypertrophic Cardiomyopathy' },
          { diagnosis: 'Congenital Heart Disease' },
          { diagnosis: 'Marfan Syndrome' },
          { diagnosis: 'Bicuspid Aortic Valve' },
          { diagnosis: 'Mitral Valve Prolapse' }
        ],
        autoimmune: [
          { diagnosis: 'Systemic Lupus Erythematosus' },
          { diagnosis: 'Rheumatoid Arthritis' },
          { diagnosis: 'Scleroderma' },
          { diagnosis: 'Polymyositis' },
          { diagnosis: 'Takayasu Arteritis' },
          { diagnosis: 'Polyarteritis Nodosa' }
        ],
        traumatic: [
          { diagnosis: 'Rib Fracture' },
          { diagnosis: 'Pneumothorax', isDangerous: true },
          { diagnosis: 'Hemothorax', isDangerous: true },
          { diagnosis: 'Cardiac Contusion' },
          { diagnosis: 'Esophageal Rupture', isDangerous: true },
          { diagnosis: 'Flail Chest', isDangerous: true },
          { diagnosis: 'Pulmonary Contusion' }
        ],
        endocrine: [
          { diagnosis: 'Hyperthyroidism' },
          { diagnosis: 'Diabetes Mellitus' },
          { diagnosis: 'Adrenal Insufficiency' },
          { diagnosis: 'Pheochromocytoma' },
          { diagnosis: 'Hyperparathyroidism' }
        ]
      },
      'hair loss': {
        vascular: [
          { diagnosis: 'Arterial Insufficiency' },
          { diagnosis: 'Temporal Arteritis' },
          { diagnosis: 'Peripheral Vascular Disease' },
          { diagnosis: 'Scalp Ischemia' },
          { diagnosis: 'Atherosclerosis' },
          { diagnosis: 'Vasculitis' }
        ],
        infectious: [
          { diagnosis: 'Tinea Capitis' },
          { diagnosis: 'Bacterial Folliculitis' },
          { diagnosis: 'Syphilis (Secondary)' },
          { diagnosis: 'Demodex Folliculorum' },
          { diagnosis: 'Kerion' },
          { diagnosis: 'Dissecting Cellulitis' }
        ],
        neoplastic: [
          { diagnosis: 'Scalp Metastases' },
          { diagnosis: 'Lymphoma' },
          { diagnosis: 'Basal Cell Carcinoma' },
          { diagnosis: 'Squamous Cell Carcinoma' },
          { diagnosis: 'Sebaceous Carcinoma' },
          { diagnosis: 'Mycosis Fungoides' }
        ],
        degenerative: [
          { diagnosis: 'Androgenetic Alopecia' },
          { diagnosis: 'Age-related Hair Loss' },
          { diagnosis: 'Senescent Alopecia' },
          { diagnosis: 'Involutional Alopecia' }
        ],
        idiopathic: [
          { diagnosis: 'Alopecia Areata' },
          { diagnosis: 'Idiopathic Hair Loss' },
          { diagnosis: 'Unexplained Alopecia' },
          { diagnosis: 'Diffuse Alopecia' }
        ],
        congenital: [
          { diagnosis: 'Congenital Alopecia' },
          { diagnosis: 'Ectodermal Dysplasia' },
          { diagnosis: 'Monilethrix' },
          { diagnosis: 'Trichorrhexis Nodosa' },
          { diagnosis: 'Pili Torti' },
          { diagnosis: 'Aplasia Cutis Congenita' }
        ],
        autoimmune: [
          { diagnosis: 'Alopecia Areata' },
          { diagnosis: 'Systemic Lupus Erythematosus' },
          { diagnosis: 'Discoid Lupus' },
          { diagnosis: 'Lichen Planopilaris' },
          { diagnosis: 'Frontal Fibrosing Alopecia' },
          { diagnosis: 'Central Centrifugal Cicatricial Alopecia' }
        ],
        traumatic: [
          { diagnosis: 'Traction Alopecia' },
          { diagnosis: 'Trichotillomania' },
          { diagnosis: 'Chemical Burns' },
          { diagnosis: 'Radiation Alopecia' },
          { diagnosis: 'Mechanical Trauma' },
          { diagnosis: 'Thermal Burns' }
        ],
        endocrine: [
          { diagnosis: 'Hypothyroidism' },
          { diagnosis: 'Hyperthyroidism' },
          { diagnosis: 'PCOS' },
          { diagnosis: 'Adrenal Disorders' },
          { diagnosis: 'Postpartum Alopecia' },
          { diagnosis: 'Hypoparathyroidism' },
          { diagnosis: 'Iron Deficiency' }
        ]
      },
      'abdominal distension': {
        vascular: [
          { diagnosis: 'Portal Hypertension' },
          { diagnosis: 'Budd-Chiari Syndrome' },
          { diagnosis: 'Mesenteric Ischemia' },
          { diagnosis: 'Abdominal Aortic Aneurysm' },
          { diagnosis: 'Inferior Vena Cava Obstruction' },
          { diagnosis: 'Hepatic Vein Thrombosis' },
          { diagnosis: 'Splenic Vein Thrombosis' }
        ],
        infectious: [
          { diagnosis: 'Peritonitis', isDangerous: true },
          { diagnosis: 'Tuberculosis Peritonitis' },
          { diagnosis: 'Parasitic Infections' },
          { diagnosis: 'Spontaneous Bacterial Peritonitis', isDangerous: true },
          { diagnosis: 'Clostridium Difficile Colitis' },
          { diagnosis: 'Viral Hepatitis' }
        ],
        neoplastic: [
          { diagnosis: 'Ovarian Cancer' },
          { diagnosis: 'Peritoneal Carcinomatosis' },
          { diagnosis: 'Gastric Cancer' },
          { diagnosis: 'Pancreatic Cancer' },
          { diagnosis: 'Lymphoma' },
          { diagnosis: 'Hepatocellular Carcinoma' },
          { diagnosis: 'Mesothelioma' }
        ],
        degenerative: [
          { diagnosis: 'Chronic Liver Disease' },
          { diagnosis: 'Cirrhosis' },
          { diagnosis: 'Chronic Pancreatitis' },
          { diagnosis: 'Chronic Kidney Disease' },
          { diagnosis: 'Protein-Energy Malnutrition' }
        ],
        idiopathic: [
          { diagnosis: 'Idiopathic Ascites' },
          { diagnosis: 'Functional Bloating' },
          { diagnosis: 'Unknown Etiology' },
          { diagnosis: 'Idiopathic Bowel Obstruction' }
        ],
        congenital: [
          { diagnosis: 'Polycystic Kidney Disease' },
          { diagnosis: 'Congenital Diaphragmatic Hernia' },
          { diagnosis: 'Hirschsprung Disease' },
          { diagnosis: 'Intestinal Malrotation' },
          { diagnosis: 'Congenital Hepatic Fibrosis' }
        ],
        autoimmune: [
          { diagnosis: 'Autoimmune Hepatitis' },
          { diagnosis: 'Primary Biliary Cholangitis' },
          { diagnosis: 'Inflammatory Bowel Disease' },
          { diagnosis: 'Systemic Lupus Erythematosus' },
          { diagnosis: 'Primary Sclerosing Cholangitis' },
          { diagnosis: 'Celiac Disease' }
        ],
        traumatic: [
          { diagnosis: 'Hemoperitoneum', isDangerous: true },
          { diagnosis: 'Bowel Perforation', isDangerous: true },
          { diagnosis: 'Splenic Rupture', isDangerous: true },
          { diagnosis: 'Liver Laceration', isDangerous: true },
          { diagnosis: 'Mesenteric Tear', isDangerous: true },
          { diagnosis: 'Retroperitoneal Hematoma', isDangerous: true }
        ],
        endocrine: [
          { diagnosis: 'Hypothyroidism' },
          { diagnosis: 'Diabetes Mellitus' },
          { diagnosis: 'Cushing Syndrome' },
          { diagnosis: 'Adrenal Insufficiency' },
          { diagnosis: 'Hyperaldosteronism' },
          { diagnosis: 'Pheochromocytoma' }
        ]
      },
      'headache': {
        vascular: [
          { diagnosis: 'Subarachnoid Hemorrhage', isDangerous: true },
          { diagnosis: 'Intracerebral Hemorrhage', isDangerous: true },
          { diagnosis: 'Cerebral Venous Thrombosis', isDangerous: true },
          { diagnosis: 'Migraine' },
          { diagnosis: 'Cluster Headache' },
          { diagnosis: 'Temporal Arteritis', isDangerous: true },
          { diagnosis: 'Carotid Dissection', isDangerous: true },
          { diagnosis: 'Vertebral Dissection', isDangerous: true }
        ],
        infectious: [
          { diagnosis: 'Meningitis', isDangerous: true },
          { diagnosis: 'Encephalitis', isDangerous: true },
          { diagnosis: 'Brain Abscess', isDangerous: true },
          { diagnosis: 'Sinusitis' },
          { diagnosis: 'Dental Abscess' },
          { diagnosis: 'Subdural Empyema', isDangerous: true },
          { diagnosis: 'Epidural Abscess', isDangerous: true }
        ],
        neoplastic: [
          { diagnosis: 'Brain Tumor', isDangerous: true },
          { diagnosis: 'Meningioma' },
          { diagnosis: 'Metastatic Disease' },
          { diagnosis: 'Pituitary Adenoma' },
          { diagnosis: 'Glioblastoma', isDangerous: true },
          { diagnosis: 'Lymphoma' }
        ],
        degenerative: [
          { diagnosis: 'Cervical Spondylosis' },
          { diagnosis: 'Temporomandibular Joint Disorder' },
          { diagnosis: 'Chronic Daily Headache' },
          { diagnosis: 'Medication Overuse Headache' },
          { diagnosis: 'Cervicogenic Headache' }
        ],
        idiopathic: [
          { diagnosis: 'Primary Headache Disorder' },
          { diagnosis: 'Idiopathic Intracranial Hypertension' },
          { diagnosis: 'Tension-type Headache' },
          { diagnosis: 'New Daily Persistent Headache' }
        ],
        congenital: [
          { diagnosis: 'Chiari Malformation' },
          { diagnosis: 'Arteriovenous Malformation' },
          { diagnosis: 'Congenital Hydrocephalus' },
          { diagnosis: 'Dandy-Walker Malformation' },
          { diagnosis: 'Arachnoid Cyst' }
        ],
        autoimmune: [
          { diagnosis: 'Systemic Lupus Erythematosus' },
          { diagnosis: 'Antiphospholipid Syndrome' },
          { diagnosis: 'Vasculitis' },
          { diagnosis: 'Multiple Sclerosis' },
          { diagnosis: 'Behcet Disease' },
          { diagnosis: 'Sarcoidosis' }
        ],
        traumatic: [
          { diagnosis: 'Post-concussion Syndrome' },
          { diagnosis: 'Subdural Hematoma', isDangerous: true },
          { diagnosis: 'Epidural Hematoma', isDangerous: true },
          { diagnosis: 'Traumatic Brain Injury' },
          { diagnosis: 'Diffuse Axonal Injury', isDangerous: true },
          { diagnosis: 'Cerebral Contusion' }
        ],
        endocrine: [
          { diagnosis: 'Hypothyroidism' },
          { diagnosis: 'Hyperthyroidism' },
          { diagnosis: 'Diabetes Mellitus' },
          { diagnosis: 'Pheochromocytoma' },
          { diagnosis: 'Hyperparathyroidism' },
          { diagnosis: 'Adrenal Insufficiency' }
        ]
      },
      'dyspnea': {
        vascular: [
          { diagnosis: 'Pulmonary Embolism', isDangerous: true },
          { diagnosis: 'Congestive Heart Failure' },
          { diagnosis: 'Myocardial Infarction', isDangerous: true },
          { diagnosis: 'Pulmonary Hypertension' },
          { diagnosis: 'Aortic Stenosis' },
          { diagnosis: 'Mitral Stenosis' },
          { diagnosis: 'Pulmonary Edema', isDangerous: true }
        ],
        infectious: [
          { diagnosis: 'Pneumonia' },
          { diagnosis: 'Tuberculosis' },
          { diagnosis: 'COVID-19' },
          { diagnosis: 'Bronchitis' },
          { diagnosis: 'Empyema' },
          { diagnosis: 'Lung Abscess' },
          { diagnosis: 'Sepsis', isDangerous: true }
        ],
        neoplastic: [
          { diagnosis: 'Lung Cancer' },
          { diagnosis: 'Pleural Mesothelioma' },
          { diagnosis: 'Mediastinal Mass' },
          { diagnosis: 'Metastatic Disease' },
          { diagnosis: 'Lymphangitic Carcinomatosis' },
          { diagnosis: 'Superior Vena Cava Syndrome', isDangerous: true }
        ],
        degenerative: [
          { diagnosis: 'COPD' },
          { diagnosis: 'Pulmonary Fibrosis' },
          { diagnosis: 'Emphysema' },
          { diagnosis: 'Chronic Bronchitis' },
          { diagnosis: 'Bronchiectasis' },
          { diagnosis: 'Interstitial Lung Disease' }
        ],
        idiopathic: [
          { diagnosis: 'Idiopathic Pulmonary Fibrosis' },
          { diagnosis: 'Idiopathic Pulmonary Hypertension' },
          { diagnosis: 'Unexplained Dyspnea' },
          { diagnosis: 'Idiopathic Interstitial Pneumonia' }
        ],
        congenital: [
          { diagnosis: 'Congenital Heart Disease' },
          { diagnosis: 'Cystic Fibrosis' },
          { diagnosis: 'Alpha-1 Antitrypsin Deficiency' },
          { diagnosis: 'Primary Ciliary Dyskinesia' },
          { diagnosis: 'Congenital Diaphragmatic Hernia' }
        ],
        autoimmune: [
          { diagnosis: 'Asthma' },
          { diagnosis: 'Systemic Lupus Erythematosus' },
          { diagnosis: 'Rheumatoid Arthritis' },
          { diagnosis: 'Sarcoidosis' },
          { diagnosis: 'Hypersensitivity Pneumonitis' },
          { diagnosis: 'Eosinophilic Granulomatosis with Polyangiitis' }
        ],
        traumatic: [
          { diagnosis: 'Pneumothorax', isDangerous: true },
          { diagnosis: 'Hemothorax', isDangerous: true },
          { diagnosis: 'Pulmonary Contusion' },
          { diagnosis: 'Rib Fractures' },
          { diagnosis: 'Flail Chest', isDangerous: true },
          { diagnosis: 'Fat Embolism', isDangerous: true }
        ],
        endocrine: [
          { diagnosis: 'Hyperthyroidism' },
          { diagnosis: 'Diabetes Mellitus' },
          { diagnosis: 'Obesity' },
          { diagnosis: 'Anemia' },
          { diagnosis: 'Diabetic Ketoacidosis', isDangerous: true },
          { diagnosis: 'Myxedema' }
        ]
      },
      'abdominal pain': {
        vascular: [
          { diagnosis: 'Abdominal Aortic Aneurysm', isDangerous: true },
          { diagnosis: 'Mesenteric Ischemia', isDangerous: true },
          { diagnosis: 'Splenic Infarction' },
          { diagnosis: 'Renal Infarction' },
          { diagnosis: 'Ischemic Colitis' },
          { diagnosis: 'Celiac Artery Stenosis' }
        ],
        infectious: [
          { diagnosis: 'Appendicitis', isDangerous: true },
          { diagnosis: 'Diverticulitis' },
          { diagnosis: 'Cholangitis', isDangerous: true },
          { diagnosis: 'Pyelonephritis' },
          { diagnosis: 'Gastroenteritis' },
          { diagnosis: 'Cholecystitis' },
          { diagnosis: 'Pancreatitis' }
        ],
        neoplastic: [
          { diagnosis: 'Pancreatic Cancer' },
          { diagnosis: 'Gastric Cancer' },
          { diagnosis: 'Ovarian Cancer' },
          { diagnosis: 'Colorectal Cancer' },
          { diagnosis: 'Hepatocellular Carcinoma' },
          { diagnosis: 'Lymphoma' }
        ],
        degenerative: [
          { diagnosis: 'Peptic Ulcer Disease' },
          { diagnosis: 'Chronic Pancreatitis' },
          { diagnosis: 'Inflammatory Bowel Disease' },
          { diagnosis: 'Gallstone Disease' },
          { diagnosis: 'Chronic Cholecystitis' }
        ],
        idiopathic: [
          { diagnosis: 'Functional Dyspepsia' },
          { diagnosis: 'Irritable Bowel Syndrome' },
          { diagnosis: 'Non-specific Abdominal Pain' },
          { diagnosis: 'Functional Abdominal Pain' }
        ],
        congenital: [
          { diagnosis: 'Meckel Diverticulum' },
          { diagnosis: 'Malrotation' },
          { diagnosis: 'Hirschsprung Disease' },
          { diagnosis: 'Duodenal Atresia' },
          { diagnosis: 'Annular Pancreas' }
        ],
        autoimmune: [
          { diagnosis: 'Crohn Disease' },
          { diagnosis: 'Ulcerative Colitis' },
          { diagnosis: 'Autoimmune Pancreatitis' },
          { diagnosis: 'Celiac Disease' },
          { diagnosis: 'Primary Sclerosing Cholangitis' },
          { diagnosis: 'Autoimmune Hepatitis' }
        ],
        traumatic: [
          { diagnosis: 'Splenic Rupture', isDangerous: true },
          { diagnosis: 'Liver Laceration', isDangerous: true },
          { diagnosis: 'Bowel Perforation', isDangerous: true },
          { diagnosis: 'Pancreatic Trauma' },
          { diagnosis: 'Retroperitoneal Hematoma', isDangerous: true },
          { diagnosis: 'Duodenal Hematoma' }
        ],
        endocrine: [
          { diagnosis: 'Diabetic Ketoacidosis', isDangerous: true },
          { diagnosis: 'Adrenal Crisis', isDangerous: true },
          { diagnosis: 'Hypercalcemia' },
          { diagnosis: 'Porphyria' },
          { diagnosis: 'Hyperparathyroidism' },
          { diagnosis: 'Thyroid Storm', isDangerous: true }
        ]
      },
      'joint pain': {
        vascular: [
          { diagnosis: 'Avascular Necrosis' },
          { diagnosis: 'Vasculitis' },
          { diagnosis: 'Thrombotic Microangiopathy' },
          { diagnosis: 'Ischemic Bone Disease' },
          { diagnosis: 'Polyarteritis Nodosa' },
          { diagnosis: 'Hypersensitivity Vasculitis' }
        ],
        infectious: [
          { diagnosis: 'Septic Arthritis', isDangerous: true },
          { diagnosis: 'Osteomyelitis', isDangerous: true },
          { diagnosis: 'Lyme Disease' },
          { diagnosis: 'Viral Arthritis' },
          { diagnosis: 'Gonococcal Arthritis' },
          { diagnosis: 'Tuberculous Arthritis' },
          { diagnosis: 'Fungal Arthritis' }
        ],
        neoplastic: [
          { diagnosis: 'Bone Metastases' },
          { diagnosis: 'Primary Bone Tumor' },
          { diagnosis: 'Leukemia' },
          { diagnosis: 'Multiple Myeloma' },
          { diagnosis: 'Osteosarcoma' },
          { diagnosis: 'Synovial Sarcoma' }
        ],
        degenerative: [
          { diagnosis: 'Osteoarthritis' },
          { diagnosis: 'Degenerative Joint Disease' },
          { diagnosis: 'Spinal Stenosis' },
          { diagnosis: 'Degenerative Disc Disease' },
          { diagnosis: 'Chondromalacia Patellae' }
        ],
        idiopathic: [
          { diagnosis: 'Idiopathic Arthritis' },
          { diagnosis: 'Fibromyalgia' },
          { diagnosis: 'Non-specific Joint Pain' },
          { diagnosis: 'Idiopathic Juvenile Arthritis' }
        ],
        congenital: [
          { diagnosis: 'Congenital Hip Dysplasia' },
          { diagnosis: 'Ehlers-Danlos Syndrome' },
          { diagnosis: 'Marfan Syndrome' },
          { diagnosis: 'Osteogenesis Imperfecta' },
          { diagnosis: 'Mucopolysaccharidoses' }
        ],
        autoimmune: [
          { diagnosis: 'Rheumatoid Arthritis' },
          { diagnosis: 'Systemic Lupus Erythematosus' },
          { diagnosis: 'Psoriatic Arthritis' },
          { diagnosis: 'Ankylosing Spondylitis' },
          { diagnosis: 'Reactive Arthritis' },
          { diagnosis: 'Sjögren Syndrome' },
          { diagnosis: 'Systemic Sclerosis' }
        ],
        traumatic: [
          { diagnosis: 'Fracture' },
          { diagnosis: 'Ligament Tear' },
          { diagnosis: 'Meniscal Tear' },
          { diagnosis: 'Dislocation' },
          { diagnosis: 'Rotator Cuff Tear' },
          { diagnosis: 'Stress Fracture' }
        ],
        endocrine: [
          { diagnosis: 'Gout' },
          { diagnosis: 'Pseudogout' },
          { diagnosis: 'Hyperparathyroidism' },
          { diagnosis: 'Hypothyroidism' },
          { diagnosis: 'Diabetes Mellitus' },
          { diagnosis: 'Acromegaly' }
        ]
      },
      'fever': {
        vascular: [
          { diagnosis: 'Pulmonary Embolism', isDangerous: true },
          { diagnosis: 'Deep Vein Thrombosis' },
          { diagnosis: 'Vasculitis' },
          { diagnosis: 'Thrombophlebitis' },
          { diagnosis: 'Aortic Dissection', isDangerous: true },
          { diagnosis: 'Myocardial Infarction' }
        ],
        infectious: [
          { diagnosis: 'Sepsis', isDangerous: true },
          { diagnosis: 'Pneumonia' },
          { diagnosis: 'Urinary Tract Infection' },
          { diagnosis: 'Meningitis', isDangerous: true },
          { diagnosis: 'Endocarditis', isDangerous: true },
          { diagnosis: 'Cellulitis' },
          { diagnosis: 'Osteomyelitis' },
          { diagnosis: 'Intra-abdominal Abscess' }
        ],
        neoplastic: [
          { diagnosis: 'Lymphoma' },
          { diagnosis: 'Leukemia' },
          { diagnosis: 'Solid Organ Malignancy' },
          { diagnosis: 'Tumor Fever' },
          { diagnosis: 'Neutropenic Fever', isDangerous: true },
          { diagnosis: 'Tumor Lysis Syndrome', isDangerous: true }
        ],
        degenerative: [
          { diagnosis: 'Drug-induced Fever' },
          { diagnosis: 'Heat Stroke', isDangerous: true },
          { diagnosis: 'Neuroleptic Malignant Syndrome', isDangerous: true },
          { diagnosis: 'Malignant Hyperthermia', isDangerous: true }
        ],
        idiopathic: [
          { diagnosis: 'Fever of Unknown Origin' },
          { diagnosis: 'Idiopathic Fever' },
          { diagnosis: 'Factitious Fever' }
        ],
        congenital: [
          { diagnosis: 'Immunodeficiency Syndromes' },
          { diagnosis: 'Hereditary Fever Syndromes' },
          { diagnosis: 'Familial Mediterranean Fever' },
          { diagnosis: 'Hyper-IgD Syndrome' }
        ],
        autoimmune: [
          { diagnosis: 'Systemic Lupus Erythematosus' },
          { diagnosis: 'Rheumatoid Arthritis' },
          { diagnosis: 'Adult Still Disease' },
          { diagnosis: 'Inflammatory Bowel Disease' },
          { diagnosis: 'Temporal Arteritis' },
          { diagnosis: 'Polymyalgia Rheumatica' }
        ],
        traumatic: [
          { diagnosis: 'Post-operative Fever' },
          { diagnosis: 'Fat Embolism' },
          { diagnosis: 'Rhabdomyolysis' },
          { diagnosis: 'Crush Syndrome', isDangerous: true },
          { diagnosis: 'Transfusion Reaction' }
        ],
        endocrine: [
          { diagnosis: 'Thyroid Storm', isDangerous: true },
          { diagnosis: 'Adrenal Crisis', isDangerous: true },
          { diagnosis: 'Diabetic Ketoacidosis', isDangerous: true },
          { diagnosis: 'Pheochromocytoma Crisis', isDangerous: true },
          { diagnosis: 'Hypercalcemic Crisis', isDangerous: true }
        ]
      }
    };

    // Additional comprehensive presentations
    const additionalPresentations = {
      'syncope': {
        vascular: [
          { diagnosis: 'Aortic Stenosis', isDangerous: true },
          { diagnosis: 'Hypertrophic Cardiomyopathy', isDangerous: true },
          { diagnosis: 'Pulmonary Embolism', isDangerous: true },
          { diagnosis: 'Aortic Dissection', isDangerous: true },
          { diagnosis: 'Orthostatic Hypotension' },
          { diagnosis: 'Carotid Sinus Hypersensitivity' }
        ],
        infectious: [
          { diagnosis: 'Sepsis', isDangerous: true },
          { diagnosis: 'Endocarditis' },
          { diagnosis: 'Myocarditis' },
          { diagnosis: 'Dehydration from Gastroenteritis' }
        ],
        neoplastic: [
          { diagnosis: 'Cardiac Myxoma' },
          { diagnosis: 'Brain Tumor' },
          { diagnosis: 'Paraneoplastic Syndrome' }
        ],
        degenerative: [
          { diagnosis: 'Sick Sinus Syndrome' },
          { diagnosis: 'Complete Heart Block', isDangerous: true },
          { diagnosis: 'Degenerative Valve Disease' }
        ],
        idiopathic: [
          { diagnosis: 'Vasovagal Syncope' },
          { diagnosis: 'Situational Syncope' },
          { diagnosis: 'Idiopathic Syncope' }
        ],
        congenital: [
          { diagnosis: 'Long QT Syndrome', isDangerous: true },
          { diagnosis: 'Brugada Syndrome', isDangerous: true },
          { diagnosis: 'Arrhythmogenic Right Ventricular Cardiomyopathy', isDangerous: true }
        ],
        autoimmune: [
          { diagnosis: 'Systemic Lupus Erythematosus' },
          { diagnosis: 'Antiphospholipid Syndrome' },
          { diagnosis: 'Myasthenia Gravis' }
        ],
        traumatic: [
          { diagnosis: 'Traumatic Brain Injury' },
          { diagnosis: 'Cardiac Contusion' },
          { diagnosis: 'Hemorrhage', isDangerous: true }
        ],
        endocrine: [
          { diagnosis: 'Hypoglycemia', isDangerous: true },
          { diagnosis: 'Adrenal Insufficiency', isDangerous: true },
          { diagnosis: 'Hyperthyroidism' },
          { diagnosis: 'Pheochromocytoma' }
        ]
      },
      'palpitations': {
        vascular: [
          { diagnosis: 'Atrial Fibrillation' },
          { diagnosis: 'Ventricular Tachycardia', isDangerous: true },
          { diagnosis: 'Supraventricular Tachycardia' },
          { diagnosis: 'Premature Ventricular Contractions' },
          { diagnosis: 'Atrial Flutter' }
        ],
        infectious: [
          { diagnosis: 'Myocarditis' },
          { diagnosis: 'Endocarditis' },
          { diagnosis: 'Sepsis', isDangerous: true },
          { diagnosis: 'Rheumatic Heart Disease' }
        ],
        neoplastic: [
          { diagnosis: 'Cardiac Myxoma' },
          { diagnosis: 'Pheochromocytoma' },
          { diagnosis: 'Carcinoid Syndrome' }
        ],
        degenerative: [
          { diagnosis: 'Ischemic Heart Disease' },
          { diagnosis: 'Cardiomyopathy' },
          { diagnosis: 'Valvular Heart Disease' }
        ],
        idiopathic: [
          { diagnosis: 'Idiopathic Atrial Fibrillation' },
          { diagnosis: 'Lone Atrial Fibrillation' },
          { diagnosis: 'Benign Palpitations' }
        ],
        congenital: [
          { diagnosis: 'Wolff-Parkinson-White Syndrome' },
          { diagnosis: 'Long QT Syndrome', isDangerous: true },
          { diagnosis: 'Congenital Heart Disease' }
        ],
        autoimmune: [
          { diagnosis: 'Systemic Lupus Erythematosus' },
          { diagnosis: 'Rheumatoid Arthritis' },
          { diagnosis: 'Sarcoidosis' }
        ],
        traumatic: [
          { diagnosis: 'Cardiac Contusion' },
          { diagnosis: 'Commotio Cordis', isDangerous: true },
          { diagnosis: 'Electrocution' }
        ],
        endocrine: [
          { diagnosis: 'Hyperthyroidism' },
          { diagnosis: 'Pheochromocytoma' },
          { diagnosis: 'Hypoglycemia' },
          { diagnosis: 'Hyperparathyroidism' }
        ]
      },
      'nausea': {
        vascular: [
          { diagnosis: 'Myocardial Infarction', isDangerous: true },
          { diagnosis: 'Mesenteric Ischemia', isDangerous: true },
          { diagnosis: 'Migraine' }
        ],
        infectious: [
          { diagnosis: 'Gastroenteritis' },
          { diagnosis: 'Food Poisoning' },
          { diagnosis: 'Hepatitis' },
          { diagnosis: 'Meningitis', isDangerous: true }
        ],
        neoplastic: [
          { diagnosis: 'Gastric Cancer' },
          { diagnosis: 'Pancreatic Cancer' },
          { diagnosis: 'Brain Tumor' },
          { diagnosis: 'Chemotherapy-induced' }
        ],
        degenerative: [
          { diagnosis: 'Peptic Ulcer Disease' },
          { diagnosis: 'Gastroparesis' },
          { diagnosis: 'Chronic Kidney Disease' }
        ],
        idiopathic: [
          { diagnosis: 'Functional Dyspepsia' },
          { diagnosis: 'Cyclic Vomiting Syndrome' },
          { diagnosis: 'Motion Sickness' }
        ],
        congenital: [
          { diagnosis: 'Pyloric Stenosis' },
          { diagnosis: 'Malrotation' },
          { diagnosis: 'Hirschsprung Disease' }
        ],
        autoimmune: [
          { diagnosis: 'Celiac Disease' },
          { diagnosis: 'Inflammatory Bowel Disease' },
          { diagnosis: 'Autoimmune Gastritis' }
        ],
        traumatic: [
          { diagnosis: 'Traumatic Brain Injury' },
          { diagnosis: 'Concussion' },
          { diagnosis: 'Abdominal Trauma' }
        ],
        endocrine: [
          { diagnosis: 'Diabetic Ketoacidosis', isDangerous: true },
          { diagnosis: 'Adrenal Insufficiency', isDangerous: true },
          { diagnosis: 'Hypercalcemia' },
          { diagnosis: 'Pregnancy' }
        ]
      }
    };

    // Merge additional presentations
    Object.assign(differentials, additionalPresentations);

    const defaultDifferentials = {
      'default': {
        vascular: [
          { diagnosis: 'Vascular Disease' },
          { diagnosis: 'Circulatory Disorder' },
          { diagnosis: 'Vascular Emergency', isDangerous: true },
          { diagnosis: 'Thrombosis' },
          { diagnosis: 'Embolism', isDangerous: true }
        ],
        infectious: [
          { diagnosis: 'Bacterial Infection' },
          { diagnosis: 'Viral Infection' },
          { diagnosis: 'Sepsis', isDangerous: true },
          { diagnosis: 'Fungal Infection' },
          { diagnosis: 'Parasitic Infection' }
        ],
        neoplastic: [
          { diagnosis: 'Primary Malignancy' },
          { diagnosis: 'Metastatic Disease' },
          { diagnosis: 'Benign Tumor' },
          { diagnosis: 'Hematologic Malignancy' },
          { diagnosis: 'Paraneoplastic Syndrome' }
        ],
        degenerative: [
          { diagnosis: 'Age-related Changes' },
          { diagnosis: 'Wear and Tear' },
          { diagnosis: 'Chronic Disease' },
          { diagnosis: 'Progressive Disorder' }
        ],
        idiopathic: [
          { diagnosis: 'Unknown Cause' },
          { diagnosis: 'Unknown Etiology' },
          { diagnosis: 'Primary Disorder' },
          { diagnosis: 'Functional Disorder' }
        ],
        congenital: [
          { diagnosis: 'Birth Defect' },
          { diagnosis: 'Genetic Condition' },
          { diagnosis: 'Chromosomal Abnormality' },
          { diagnosis: 'Inherited Disorder' }
        ],
        autoimmune: [
          { diagnosis: 'Immune System Disorder' },
          { diagnosis: 'Inflammatory Disease' },
          { diagnosis: 'Autoimmune Condition' },
          { diagnosis: 'Hypersensitivity Reaction' }
        ],
        traumatic: [
          { diagnosis: 'Acute Trauma' },
          { diagnosis: 'Chronic Injury' },
          { diagnosis: 'Mechanical Injury' },
          { diagnosis: 'Iatrogenic Injury' }
        ],
        endocrine: [
          { diagnosis: 'Hormonal Imbalance' },
          { diagnosis: 'Metabolic Condition' },
          { diagnosis: 'Endocrine Dysfunction' },
          { diagnosis: 'Electrolyte Imbalance' }
        ]
      }
    };

    // Get differentials for current presentation, fallback to default
    const presentationDifferentials = differentials[presentation] || defaultDifferentials['default'];
    return presentationDifferentials[category || 'vascular'] || [];
  };

  const differentials = getDifferentials();

  return (
    <div className="min-h-screen py-16 sm:py-20 px-6 sm:px-6 bg-pure-white dark:bg-dark-background transition-colors duration-300 flex flex-col items-center justify-center">
      <div className="container mx-auto max-w-xs w-full">
        <div className="text-center mb-8 sm:mb-12">
          {/* Boxed Presentation Title */}
          <div className="mb-4 px-4 py-3 border-2 border-royal-blue dark:border-white rounded-luxury bg-soft-gray dark:bg-dark-surface-elevated shadow-luxury-soft dark:shadow-dark-luxury-soft">
            <h1 className="text-lg sm:text-xl font-cambria font-normal text-royal-blue dark:text-white tracking-wide leading-relaxed">
              {currentPresentation}
            </h1>
          </div>
          
          {/* Category Name - Smaller underneath */}
          <h2 className="text-sm sm:text-base font-cambria font-normal mb-4 tracking-wide text-royal-blue dark:text-white leading-relaxed">
            {getCategoryDisplayName()}
          </h2>
          
          <p className="text-xs text-royal-blue dark:text-white font-cambria font-normal leading-relaxed px-4 mb-2">
            Tap to reveal differential
          </p>
          
          <p className="text-xs text-royal-blue dark:text-white font-cambria font-normal leading-relaxed px-4">
            Red borders indicate do not miss diagnoses
          </p>
        </div>

        {/* Toggle Controls */}
        <ToggleControls
          chronicity={chronicity}
          onChronicityChange={setChronicity}
          biologicalSex={biologicalSex}
          onBiologicalSexChange={setBiologicalSex}
          age={age}
          onAgeChange={setAge}
          ageRange={getAgeRange()}
          category={category}
        />

        {/* Differential Diagnoses Grid */}
        <div className="grid grid-cols-1 gap-3 sm:gap-4 w-full">
          {differentials.map((item, index) => (
            <RevealTile
              key={`${item.diagnosis}-${index}`}
              diagnosis={item.diagnosis}
              clickCount={clickCounts[item.diagnosis] || 0}
              onReveal={() => handleReveal(item.diagnosis)}
              onHide={() => handleHide(item.diagnosis)}
              isRevealed={revealedStates[item.diagnosis] || false}
              isDangerous={item.isDangerous}
            />
          ))}
        </div>
      </div>
    </div>
  );
};

export default RevealDifferentials;