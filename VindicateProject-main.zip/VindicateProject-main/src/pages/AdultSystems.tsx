import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Search, Shuffle, List } from 'lucide-react';
import LuxuryCard from '../components/LuxuryCard';

const AdultSystems: React.FC = () => {
  const navigate = useNavigate();
  const [clickCounts, setClickCounts] = useState<Record<string, number>>({});
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState<string[]>([]);
  const [showSearchResults, setShowSearchResults] = useState(false);
  const [showAZIndex, setShowAZIndex] = useState(false);
  const [selectedLetter, setSelectedLetter] = useState<string>('A');

  // Comprehensive list of presentations with medical and colloquial terms
  const presentations = [
    // General / Non-Specific
    { medical: 'fever', colloquial: ['fever', 'high temperature', 'hot', 'burning up', 'temperature'] },
    { medical: 'fatigue', colloquial: ['fatigue', 'tired', 'exhausted', 'worn out', 'no energy', 'malaise', 'feeling unwell'] },
    { medical: 'weight loss', colloquial: ['weight loss', 'losing weight', 'getting thinner', 'unintentional weight loss'] },
    { medical: 'weight gain', colloquial: ['weight gain', 'gaining weight', 'getting heavier', 'unexplained weight gain'] },
    { medical: 'night sweats', colloquial: ['night sweats', 'sweating at night', 'waking up sweaty', 'drenching sweats'] },
    { medical: 'lymphadenopathy', colloquial: ['swollen glands', 'enlarged lymph nodes', 'lumps in neck', 'swollen nodes'] },
    { medical: 'pallor', colloquial: ['pale skin', 'looking pale', 'loss of color', 'white as a sheet'] },
    { medical: 'jaundice', colloquial: ['yellow skin', 'yellow eyes', 'turning yellow', 'yellowing'] },
    
    // Neurology
    { medical: 'headache', colloquial: ['headache', 'head pain', 'migraine', 'head hurts', 'skull pain'] },
    { medical: 'seizure', colloquial: ['seizure', 'fit', 'convulsion', 'episode', 'shaking episode'] },
    { medical: 'syncope', colloquial: ['fainting', 'passing out', 'blackout', 'loss of consciousness', 'presyncope', 'nearly fainting'] },
    { medical: 'dizziness', colloquial: ['dizziness', 'dizzy', 'lightheaded', 'spinning', 'vertigo', 'room spinning'] },
    { medical: 'weakness', colloquial: ['weakness', 'weak', 'can\'t move properly', 'loss of strength', 'focal weakness', 'generalized weakness'] },
    { medical: 'numbness', colloquial: ['numbness', 'tingling', 'pins and needles', 'loss of feeling', 'paresthesia'] },
    { medical: 'speech disturbance', colloquial: ['speech problems', 'can\'t speak properly', 'slurred speech', 'dysarthria', 'aphasia', 'word finding difficulty'] },
    { medical: 'gait disturbance', colloquial: ['unsteady walking', 'balance problems', 'coordination issues', 'ataxia', 'walking problems'] },
    { medical: 'tremor', colloquial: ['shaking', 'trembling', 'hands shaking', 'tremor', 'involuntary movements'] },
    { medical: 'visual changes', colloquial: ['vision problems', 'sudden vision loss', 'double vision', 'diplopia', 'visual field defects', 'blind spots'] },
    { medical: 'altered mental status', colloquial: ['confusion', 'disoriented', 'not thinking clearly', 'delirium', 'acting strange', 'not themselves'] },
    { medical: 'coma', colloquial: ['unconscious', 'won\'t wake up', 'unresponsive', 'comatose'] },
    
    // Psychiatry
    { medical: 'depression', colloquial: ['depression', 'sad', 'down', 'low mood', 'feeling depressed', 'hopeless'] },
    { medical: 'anxiety', colloquial: ['anxiety', 'worried', 'nervous', 'panic', 'panic attacks', 'anxious'] },
    { medical: 'psychosis', colloquial: ['hallucinations', 'hearing voices', 'seeing things', 'delusions', 'false beliefs', 'paranoid thoughts'] },
    { medical: 'memory loss', colloquial: ['forgetful', 'can\'t remember', 'memory problems', 'cognitive decline', 'dementia symptoms'] },
    { medical: 'sleep disturbance', colloquial: ['can\'t sleep', 'trouble sleeping', 'sleeplessness', 'insomnia', 'sleeping too much', 'hypersomnia'] },
    { medical: 'suicidal ideation', colloquial: ['thoughts of suicide', 'wanting to die', 'suicidal thoughts', 'self-harm thoughts'] },
    { medical: 'aggression', colloquial: ['aggressive behavior', 'violent', 'behavioral change', 'irritable', 'angry outbursts'] },
    
    // HEENT (Head, Eye, Ear, Nose, Throat)
    { medical: 'eye pain', colloquial: ['eye pain', 'eyes hurt', 'sore eyes', 'painful eyes'] },
    { medical: 'red eye', colloquial: ['red eyes', 'bloodshot eyes', 'pink eyes', 'irritated eyes'] },
    { medical: 'loss of vision', colloquial: ['can\'t see', 'blind', 'vision loss', 'sight loss', 'sudden blindness'] },
    { medical: 'diplopia', colloquial: ['double vision', 'seeing double', 'blurred vision'] },
    { medical: 'hearing loss', colloquial: ['can\'t hear well', 'deaf', 'hearing problems', 'hard of hearing'] },
    { medical: 'tinnitus', colloquial: ['ringing in ears', 'buzzing in ears', 'ear noise', 'ears ringing'] },
    { medical: 'ear pain', colloquial: ['ear pain', 'earache', 'ears hurt', 'ear infection pain'] },
    { medical: 'ear discharge', colloquial: ['ear discharge', 'fluid from ear', 'ear drainage', 'pus from ear'] },
    { medical: 'epistaxis', colloquial: ['nosebleed', 'bloody nose', 'nose bleeding', 'nasal bleeding'] },
    { medical: 'sore throat', colloquial: ['sore throat', 'throat pain', 'scratchy throat', 'painful swallowing'] },
    { medical: 'dysphagia', colloquial: ['difficulty swallowing', 'trouble swallowing', 'food getting stuck', 'odynophagia', 'painful swallowing'] },
    { medical: 'hoarseness', colloquial: ['hoarse voice', 'raspy voice', 'lost voice', 'voice change', 'voice problems'] },
    { medical: 'neck mass', colloquial: ['lump in neck', 'neck swelling', 'neck bump', 'enlarged thyroid'] },
    
    // Cardiovascular
    { medical: 'chest pain', colloquial: ['chest pain', 'heart pain', 'chest tightness', 'chest pressure'] },
    { medical: 'palpitations', colloquial: ['palpitations', 'heart racing', 'fast heartbeat', 'heart pounding'] },
    { medical: 'dyspnea', colloquial: ['shortness of breath', 'difficulty breathing', 'breathless', 'can\'t breathe', 'exertional dyspnea', 'orthopnea', 'PND'] },
    { medical: 'peripheral edema', colloquial: ['swelling', 'fluid retention', 'puffy legs', 'swollen feet', 'ankle swelling'] },
    { medical: 'claudication', colloquial: ['leg pain walking', 'cramping when walking', 'leg cramps with exercise', 'leg pain on exertion'] },
    { medical: 'cyanosis', colloquial: ['blue lips', 'blue fingers', 'turning blue', 'purple skin'] },
    
    // Respiratory
    { medical: 'cough', colloquial: ['cough', 'coughing', 'hacking cough', 'persistent cough'] },
    { medical: 'hemoptysis', colloquial: ['coughing up blood', 'bloody cough', 'blood in sputum'] },
    { medical: 'wheezing', colloquial: ['wheezing', 'whistling breathing', 'tight chest'] },
    { medical: 'stridor', colloquial: ['noisy breathing', 'harsh breathing sound', 'loud breathing'] },
    { medical: 'pleuritic chest pain', colloquial: ['sharp chest pain', 'stabbing chest pain', 'pain when breathing'] },
    
    // Gastrointestinal
    { medical: 'abdominal pain', colloquial: ['stomach pain', 'belly pain', 'tummy ache', 'gut pain'] },
    { medical: 'nausea', colloquial: ['nausea', 'feeling sick', 'queasy', 'sick to stomach'] },
    { medical: 'vomiting', colloquial: ['vomiting', 'throwing up', 'puking', 'being sick'] },
    { medical: 'hematemesis', colloquial: ['vomiting blood', 'throwing up blood', 'bloody vomit'] },
    { medical: 'heartburn', colloquial: ['heartburn', 'acid reflux', 'burning chest', 'indigestion', 'reflux'] },
    { medical: 'diarrhea', colloquial: ['diarrhea', 'loose stools', 'runny poop', 'frequent bowel movements'] },
    { medical: 'constipation', colloquial: ['constipation', 'can\'t poop', 'blocked up', 'hard stools'] },
    { medical: 'hematochezia', colloquial: ['bright red blood in stool', 'bloody poop', 'red blood in bowel movement'] },
    { medical: 'melena', colloquial: ['black stools', 'tarry stools', 'dark poop'] },
    { medical: 'abdominal distension', colloquial: ['bloated stomach', 'swollen abdomen', 'distended belly', 'ascites', 'fluid in belly'] },
    { medical: 'change in bowel habits', colloquial: ['bowel habit change', 'different bowel movements', 'altered bowel pattern'] },
    { medical: 'rectal bleeding', colloquial: ['rectal bleeding', 'bleeding from bottom', 'rectal pain', 'anal pain'] },
    { medical: 'anorexia', colloquial: ['loss of appetite', 'don\'t want to eat', 'no appetite', 'early satiety', 'feeling full quickly'] },
    
    // Genitourinary
    { medical: 'dysuria', colloquial: ['painful urination', 'burning when peeing', 'stinging pee'] },
    { medical: 'urinary frequency', colloquial: ['frequent urination', 'peeing a lot', 'going often'] },
    { medical: 'urinary urgency', colloquial: ['urgent need to pee', 'can\'t hold it', 'sudden urge'] },
    { medical: 'hematuria', colloquial: ['blood in urine', 'bloody pee', 'red urine', 'pink urine'] },
    { medical: 'flank pain', colloquial: ['side pain', 'kidney pain', 'back side pain'] },
    { medical: 'urinary retention', colloquial: ['can\'t pee', 'unable to urinate', 'blocked bladder'] },
    { medical: 'incontinence', colloquial: ['leaking urine', 'can\'t control bladder', 'wetting self', 'urinary incontinence', 'fecal incontinence'] },
    { medical: 'pelvic pain', colloquial: ['pelvic pain', 'lower abdominal pain', 'gynecologic pain'] },
    { medical: 'vaginal bleeding', colloquial: ['abnormal vaginal bleeding', 'post-menopausal bleeding', 'abnormal uterine bleeding', 'irregular periods'] },
    { medical: 'vaginal discharge', colloquial: ['vaginal discharge', 'abnormal discharge', 'unusual discharge'] },
    { medical: 'dyspareunia', colloquial: ['painful intercourse', 'pain during sex', 'painful sex'] },
    { medical: 'testicular pain', colloquial: ['testicle pain', 'ball pain', 'groin pain', 'testicular mass', 'scrotal pain'] },
    { medical: 'erectile dysfunction', colloquial: ['can\'t get erection', 'impotence', 'ED'] },
    { medical: 'infertility', colloquial: ['can\'t get pregnant', 'fertility problems', 'trouble conceiving'] },
    
    // Musculoskeletal
    { medical: 'joint pain', colloquial: ['joint pain', 'achy joints', 'sore joints', 'stiff joints'] },
    { medical: 'joint swelling', colloquial: ['swollen joints', 'puffy joints', 'joint inflammation', 'redness of joint'] },
    { medical: 'morning stiffness', colloquial: ['morning stiffness', 'stiff in morning', 'joint stiffness'] },
    { medical: 'back pain', colloquial: ['back pain', 'backache', 'sore back', 'spine pain'] },
    { medical: 'neck pain', colloquial: ['neck pain', 'stiff neck', 'sore neck', 'neck ache'] },
    { medical: 'limb pain', colloquial: ['arm pain', 'leg pain', 'limb pain', 'extremity pain'] },
    { medical: 'muscle pain', colloquial: ['muscle pain', 'sore muscles', 'muscle aches', 'body aches'] },
    { medical: 'deformity', colloquial: ['deformity', 'trauma', 'fracture', 'broken bone', 'injury'] },
    
    // Dermatological
    { medical: 'rash', colloquial: ['rash', 'skin rash', 'red spots', 'skin irritation'] },
    { medical: 'pruritus', colloquial: ['itching', 'itchy skin', 'scratching', 'skin itches'] },
    { medical: 'skin lesion', colloquial: ['skin lesion', 'skin mass', 'lump on skin', 'skin growth'] },
    { medical: 'ulcer', colloquial: ['ulcer', 'non-healing wound', 'open sore', 'skin breakdown'] },
    { medical: 'hair loss', colloquial: ['hair loss', 'balding', 'losing hair', 'nail changes', 'abnormal nails'] },
    { medical: 'bruising', colloquial: ['bruising', 'black and blue', 'bruises easily', 'purpura', 'petechiae', 'tiny red spots'] },
    
    // Endocrine / Metabolic
    { medical: 'polyuria', colloquial: ['excessive urination', 'peeing too much', 'large amounts of urine'] },
    { medical: 'polydipsia', colloquial: ['excessive thirst', 'always thirsty', 'drinking lots of water'] },
    { medical: 'polyphagia', colloquial: ['excessive hunger', 'always hungry', 'eating a lot'] },
    { medical: 'heat intolerance', colloquial: ['can\'t stand heat', 'always hot', 'overheating'] },
    { medical: 'cold intolerance', colloquial: ['always cold', 'can\'t get warm', 'sensitive to cold'] },
    { medical: 'amenorrhea', colloquial: ['no periods', 'missed periods', 'absent menstruation', 'irregular menses'] },
    { medical: 'hirsutism', colloquial: ['excessive hair growth', 'male pattern hair', 'unwanted hair'] },
    { medical: 'gynecomastia', colloquial: ['breast enlargement in men', 'male breast growth'] },
    
    // Pediatrics (special considerations)
    { medical: 'failure to thrive', colloquial: ['failure to thrive', 'not growing', 'poor weight gain', 'developmental problems'] },
    { medical: 'developmental delay', colloquial: ['developmental delay', 'late milestones', 'slow development'] },
    { medical: 'poor feeding', colloquial: ['poor feeding', 'won\'t eat', 'feeding problems', 'difficulty feeding'] },
    { medical: 'irritability', colloquial: ['irritable baby', 'fussy', 'crying', 'lethargy', 'sleepy baby'] },
    { medical: 'fever without source', colloquial: ['fever without source', 'unexplained fever', 'fever of unknown origin'] },
    
    // Obstetrics
    { medical: 'first trimester bleeding', colloquial: ['early pregnancy bleeding', 'bleeding in first trimester', 'spotting in pregnancy'] },
    { medical: 'hyperemesis gravidarum', colloquial: ['severe morning sickness', 'excessive vomiting in pregnancy', 'can\'t keep food down'] },
    { medical: 'abdominal pain in pregnancy', colloquial: ['stomach pain while pregnant', 'belly pain in pregnancy', 'pregnant abdominal pain'] },
    { medical: 'decreased fetal movement', colloquial: ['baby not moving', 'reduced fetal movement', 'baby moving less'] },
    { medical: 'hypertension in pregnancy', colloquial: ['high blood pressure in pregnancy', 'pregnancy hypertension', 'preeclampsia'] },
    { medical: 'labour pain', colloquial: ['labor pain', 'contractions', 'giving birth', 'delivery pain'] },
    { medical: 'postpartum hemorrhage', colloquial: ['bleeding after delivery', 'postpartum bleeding', 'heavy bleeding after birth'] }
  ];

  // Get random presentation
  const getRandomPresentation = () => {
    const randomIndex = Math.floor(Math.random() * presentations.length);
    const randomPresentation = presentations[randomIndex].medical;
    
    // Store the selected presentation for the VINDICATE framework
    localStorage.setItem('current-presentation', randomPresentation);
    
    // Navigate to VINDICATE framework
    navigate('/vindicate-framework');
  };

  // Group presentations alphabetically
  const getAlphabeticalPresentations = () => {
    return presentations
      .map(p => p.medical)
      .sort()
      .reduce((acc, presentation) => {
        const firstLetter = presentation.charAt(0).toUpperCase();
        if (!acc[firstLetter]) {
          acc[firstLetter] = [];
        }
        acc[firstLetter].push(presentation);
        return acc;
      }, {} as Record<string, string[]>);
  };

  // Get available letters that have presentations
  const getAvailableLetters = () => {
    const alphabeticalPresentations = getAlphabeticalPresentations();
    return Object.keys(alphabeticalPresentations).sort();
  };

  const handleSearch = (query: string) => {
    setSearchQuery(query);
    
    if (query.trim().length < 2) {
      setSearchResults([]);
      setShowSearchResults(false);
      return;
    }

    const results = presentations.filter(presentation => {
      const searchTerm = query.toLowerCase().trim();
      
      // Check medical term
      if (presentation.medical.toLowerCase().includes(searchTerm)) {
        return true;
      }
      
      // Check colloquial terms
      return presentation.colloquial.some(term => 
        term.toLowerCase().includes(searchTerm)
      );
    }).map(p => p.medical);

    setSearchResults(results.slice(0, 8)); // Limit to 8 results
    setShowSearchResults(results.length > 0);
  };

  const handleSearchResultClick = (presentation: string) => {
    // Store the selected presentation for the VINDICATE framework
    localStorage.setItem('current-presentation', presentation);
    
    // Navigate to VINDICATE framework
    navigate('/vindicate-framework');
    setSearchQuery('');
    setShowSearchResults(false);
  };

  const handlePresentationClick = (presentation: string) => {
    // Store the selected presentation for the VINDICATE framework
    localStorage.setItem('current-presentation', presentation);
    
    // Navigate to VINDICATE framework
    navigate('/vindicate-framework');
  };

  const alphabeticalPresentations = getAlphabeticalPresentations();
  const availableLetters = getAvailableLetters();

  return (
    <div className="min-h-screen py-16 sm:py-20 px-6 sm:px-6 bg-pure-white dark:bg-dark-background transition-colors duration-300 flex flex-col items-center justify-center">
      <div className="container mx-auto max-w-xs w-full">
        {!showAZIndex ? (
          <>
            {/* Main Features */}
            <div className="space-y-6">
              {/* 1. Search Presentations */}
              <div className="relative">
                <LuxuryCard className="flex items-center py-4 px-6 rounded-luxury w-full min-h-[60px]">
                  <div className="flex items-center space-x-3 w-full">
                    <Search className="w-5 h-5 text-royal-blue dark:text-white flex-shrink-0" />
                    <input
                      type="text"
                      placeholder="Search presentations (e.g., chest pain, bloody pee)"
                      value={searchQuery}
                      onChange={(e) => handleSearch(e.target.value)}
                      className="
                        flex-1 bg-transparent text-royal-blue dark:text-white placeholder-royal-blue placeholder-opacity-60 dark:placeholder-white dark:placeholder-opacity-60
                        focus:outline-none font-cambria text-sm
                      "
                    />
                  </div>
                </LuxuryCard>
                
                {/* Search Results Dropdown */}
                {showSearchResults && (
                  <div className="absolute top-full left-0 right-0 mt-2 bg-soft-gray dark:bg-dark-surface-elevated border border-light-gray dark:border-white rounded-luxury shadow-luxury-soft dark:shadow-dark-luxury-soft z-50 max-h-64 overflow-y-auto">
                    {searchResults.map((result, index) => (
                      <button
                        key={index}
                        onClick={() => handleSearchResultClick(result)}
                        className="
                          w-full text-left px-4 py-3 hover:bg-royal-blue hover:bg-opacity-10 dark:hover:bg-royal-blue dark:hover:bg-opacity-20
                          text-royal-blue dark:text-white font-cambria text-sm
                          first:rounded-t-luxury last:rounded-b-luxury
                          transition-colors duration-200
                        "
                      >
                        {result.charAt(0).toUpperCase() + result.slice(1)}
                      </button>
                    ))}
                  </div>
                )}
              </div>

              {/* 2. Random Prompt Generator */}
              <LuxuryCard
                onClick={getRandomPresentation}
                className="flex items-center justify-center py-4 px-6 rounded-luxury w-full min-h-[60px]"
              >
                <div className="flex items-center space-x-3">
                  <Shuffle className="w-5 h-5 text-royal-blue dark:text-white" />
                  <span className="text-sm font-cambria font-normal tracking-elegant text-royal-blue dark:text-white">
                    Random Presentation
                  </span>
                </div>
              </LuxuryCard>

              {/* 3. A-Z Patient Presentation Index */}
              <LuxuryCard
                onClick={() => setShowAZIndex(true)}
                className="flex items-center justify-center py-4 px-6 rounded-luxury w-full min-h-[60px]"
              >
                <div className="flex items-center space-x-3">
                  <List className="w-5 h-5 text-royal-blue dark:text-white" />
                  <span className="text-sm font-cambria font-normal tracking-elegant text-royal-blue dark:text-white">
                    A-Z Presentation Index
                  </span>
                </div>
              </LuxuryCard>
            </div>
          </>
        ) : (
          <>
            {/* A-Z Index View */}
            <div className="text-center mb-6">
              <h2 className="text-lg font-cambria font-normal text-royal-blue dark:text-white tracking-wide mb-4">
                Presentation Index
              </h2>
            </div>

            {/* Letter Selection Dropdown */}
            <div className="mb-6">
              <select
                value={selectedLetter}
                onChange={(e) => setSelectedLetter(e.target.value)}
                className="
                  w-full py-3 px-4 rounded-luxury
                  bg-soft-gray dark:bg-dark-surface-elevated
                  border border-light-gray dark:border-white
                  text-royal-blue dark:text-white font-cambria text-sm
                  focus:outline-none focus:ring-2 focus:ring-royal-blue focus:ring-opacity-50
                  hover:bg-royal-blue hover:bg-opacity-10 dark:hover:bg-royal-blue dark:hover:bg-opacity-20
                  transition-colors duration-200 text-center
                "
              >
                {availableLetters.map((letter) => (
                  <option key={letter} value={letter}>
                    {letter}
                  </option>
                ))}
              </select>
            </div>

            {/* Selected Letter Presentations */}
            <div className="space-y-2">
              {alphabeticalPresentations[selectedLetter]?.map((presentation, index) => (
                <button
                  key={index}
                  onClick={() => handlePresentationClick(presentation)}
                  className="
                    w-full text-left px-4 py-3 rounded-luxury
                    bg-soft-gray dark:bg-dark-surface-elevated
                    border border-light-gray dark:border-white
                    hover:bg-royal-blue hover:bg-opacity-10 dark:hover:bg-royal-blue dark:hover:bg-opacity-20
                    text-royal-blue dark:text-white font-cambria text-sm
                    transition-colors duration-200
                  "
                >
                  {presentation.charAt(0).toUpperCase() + presentation.slice(1)}
                </button>
              ))}
            </div>
          </>
        )}
      </div>
    </div>
  );
};

export default AdultSystems;